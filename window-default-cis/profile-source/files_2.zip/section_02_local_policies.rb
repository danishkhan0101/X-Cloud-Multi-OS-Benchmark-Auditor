# encoding: UTF-8
# CIS Microsoft Windows Server 2022 Benchmark v5.0.0
# Section 2 - Local Policies (User Rights & Security Options)
# Auto-generated; verify organization-specific (REVIEW) controls.

control 'cis-2.2.1' do
  title 'Ensure \'Access Credential Manager as a trusted caller\' is set to \'No One\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeTrustedCredManAccessPrivilege') { should eq [] }
  end
end

control 'cis-2.2.2' do
  title 'Ensure \'Access this computer from the network\' is set to \'Administrators, Authenticated Users, ENTERPRISE DOMAIN CONTROLLERS\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.2'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeNetworkLogonRight') { should match_array ['*S-1-5-32-544', '*S-1-5-11', '*S-1-5-9'] }
  end
end

control 'cis-2.2.3' do
  title 'Ensure \'Access this computer from the network\' is set to \'Administrators, Authenticated Users\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.3'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeNetworkLogonRight') { should match_array ['*S-1-5-32-544', '*S-1-5-11'] }
  end
end

control 'cis-2.2.4' do
  title 'Ensure \'Act as part of the operating system\' is set to \'No One\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeTcbPrivilege') { should eq [] }
  end
end

control 'cis-2.2.5' do
  title 'Ensure \'Add workstations to domain\' is set to \'Administrators\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.5'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeMachineAccountPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.6' do
  title 'Ensure \'Adjust memory quotas for a process\' is set to \'Administrators, LOCAL SERVICE, NETWORK SERVICE\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeIncreaseQuotaPrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-19', '*S-1-5-20'] }
  end
end

control 'cis-2.2.7' do
  title 'Ensure \'Allow log on locally\' is set to \'Administrators, ENTERPRISE DOMAIN CONTROLLERS\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.7'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeInteractiveLogonRight') { should match_array ['*S-1-5-32-544', '*S-1-5-9'] }
  end
end

control 'cis-2.2.8' do
  title 'Ensure \'Allow log on locally\' is set to \'Administrators\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.8'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeInteractiveLogonRight') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.9' do
  title 'Ensure \'Allow log on through Remote Desktop Services\' is set to \'Administrators\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.9'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeRemoteInteractiveLogonRight') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.10' do
  title 'Ensure \'Allow log on through Remote Desktop Services\' is set to \'Administrators, Remote Desktop Users\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.10'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeRemoteInteractiveLogonRight') { should match_array ['*S-1-5-32-544', '*S-1-5-32-555'] }
  end
end

control 'cis-2.2.11' do
  title 'Ensure \'Back up files and directories\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.11'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeBackupPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.12' do
  title 'Ensure \'Change the system time\' is set to \'Administrators, LOCAL SERVICE\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.12'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeSystemtimePrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-19'] }
  end
end

control 'cis-2.2.13' do
  title 'Ensure \'Create a pagefile\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.13'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeCreatePagefilePrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.14' do
  title 'Ensure \'Create a token object\' is set to \'No One\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.14'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeCreateTokenPrivilege') { should eq [] }
  end
end

control 'cis-2.2.15' do
  title 'Ensure \'Create global objects\' is set to \'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.15'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeCreateGlobalPrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-19', '*S-1-5-20', '*S-1-5-6'] }
  end
end

control 'cis-2.2.16' do
  title 'Ensure \'Create permanent shared objects\' is set to \'No One\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.16'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeCreatePermanentPrivilege') { should eq [] }
  end
end

control 'cis-2.2.17' do
  title 'Ensure \'Create symbolic links\' is set to \'Administrators\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.17'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeCreateSymbolicLinkPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.18' do
  title 'Ensure \'Create symbolic links\' is set to \'Administrators, NT VIRTUAL MACHINE\\Virtual Machines\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.18'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeCreateSymbolicLinkPrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-83-0'] }
  end
end

control 'cis-2.2.19' do
  title 'Ensure \'Debug programs\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.19'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDebugPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.20' do
  title 'Ensure \'Deny access to this computer from the network\' to include \'Guests\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.20'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyNetworkLogonRight') { should include '*S-1-5-32-546' }
  end
end

control 'cis-2.2.21' do
  title 'Ensure \'Deny access to this computer from the network\' to include \'Guests, Local account and member of Administrators group\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.21'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyNetworkLogonRight') { should include '*S-1-5-32-546' }
    its('SeDenyNetworkLogonRight') { should include '*S-1-5-114' }
  end
end

control 'cis-2.2.22' do
  title 'Ensure \'Deny log on as a batch job\' to include \'Guests\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.22'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyBatchLogonRight') { should include '*S-1-5-32-546' }
  end
end

control 'cis-2.2.23' do
  title 'Ensure \'Deny log on as a service\' to include \'Guests\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.23'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyServiceLogonRight') { should include '*S-1-5-32-546' }
  end
end

control 'cis-2.2.24' do
  title 'Ensure \'Deny log on locally\' to include \'Guests\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.24'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyInteractiveLogonRight') { should include '*S-1-5-32-546' }
  end
end

control 'cis-2.2.25' do
  title 'Ensure \'Deny log on through Remote Desktop Services\' to include \'Guests\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.25'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyRemoteInteractiveLogonRight') { should include '*S-1-5-32-546' }
  end
end

control 'cis-2.2.26' do
  title 'Ensure \'Deny log on through Remote Desktop Services\' is set to \'Guests, Local account\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.26'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeDenyRemoteInteractiveLogonRight') { should match_array ['*S-1-5-32-546', '*S-1-5-113'] }
  end
end

control 'cis-2.2.27' do
  title 'Ensure \'Enable computer and user accounts to be trusted for delegation\' is set to \'Administrators\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.27'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeEnableDelegationPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.28' do
  title 'Ensure \'Enable computer and user accounts to be trusted for delegation\' is set to \'No One\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.28'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeEnableDelegationPrivilege') { should eq [] }
  end
end

control 'cis-2.2.29' do
  title 'Ensure \'Force shutdown from a remote system\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.29'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeRemoteShutdownPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.30' do
  title 'Ensure \'Generate security audits\' is set to \'LOCAL SERVICE, NETWORK SERVICE\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.30'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeAuditPrivilege') { should match_array ['*S-1-5-19', '*S-1-5-20'] }
  end
end

control 'cis-2.2.31' do
  title 'Ensure \'Impersonate a client after authentication\' is set to \'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.31'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeImpersonatePrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-19', '*S-1-5-20', '*S-1-5-6'] }
  end
end

control 'cis-2.2.32' do
  title 'Ensure \'Impersonate a client after authentication\' is set to \'Administrators, LOCAL SERVICE, NETWORK SERVICE, SERVICE\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.32'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeImpersonatePrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-19', '*S-1-5-20', '*S-1-5-6'] }
  end
end

control 'cis-2.2.33' do
  title 'Ensure \'Increase scheduling priority\' is set to \'Administrators, Window Manager\\Window Manager Group\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.33'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeIncreaseBasePriorityPrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-90-0'] }
  end
end

control 'cis-2.2.34' do
  title 'Ensure \'Load and unload device drivers\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.34'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeLoadDriverPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.35' do
  title 'Ensure \'Lock pages in memory\' is set to \'No One\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.35'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeLockMemoryPrivilege') { should eq [] }
  end
end

control 'cis-2.2.36' do
  title 'Ensure \'Log on as a batch job\' is set to \'Administrators\' (DC Only) (Automated)'
  impact 0.7
  tag cis_id: '2.2.36'
  tag level: ['L2']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeBatchLogonRight') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.37' do
  title 'Ensure \'Manage auditing and security log\' is set to \'Administrators\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.37'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeSecurityPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.38' do
  title 'Ensure \'Manage auditing and security log\' is set to \'Administrators\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.38'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeSecurityPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.39' do
  title 'Ensure \'Modify an object label\' is set to \'No One\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.39'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeRelabelPrivilege') { should eq [] }
  end
end

control 'cis-2.2.40' do
  title 'Ensure \'Modify firmware environment values\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.40'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeSystemEnvironmentPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.41' do
  title 'Ensure \'Perform volume maintenance tasks\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.41'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeManageVolumePrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.42' do
  title 'Ensure \'Profile single process\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.42'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeProfileSingleProcessPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.43' do
  title 'Ensure \'Profile system performance\' is set to \'Administrators, NT SERVICE\\WdiServiceHost\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.43'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeSystemProfilePrivilege') { should match_array ['*S-1-5-32-544', '*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420'] }
  end
end

control 'cis-2.2.44' do
  title 'Ensure \'Replace a process level token\' is set to \'LOCAL SERVICE, NETWORK SERVICE\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.44'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeAssignPrimaryTokenPrivilege') { should match_array ['*S-1-5-19', '*S-1-5-20'] }
  end
end

control 'cis-2.2.45' do
  title 'Ensure \'Restore files and directories\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.45'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeRestorePrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.46' do
  title 'Ensure \'Shut down the system\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.46'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeShutdownPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.2.47' do
  title 'Ensure \'Synchronize directory service data\' is set to \'No One\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.2.47'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeSyncAgentPrivilege') { should eq [] }
  end
end

control 'cis-2.2.48' do
  title 'Ensure \'Take ownership of files or other objects\' is set to \'Administrators\' (Automated)'
  impact 0.5
  tag cis_id: '2.2.48'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'user_rights'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('SeTakeOwnershipPrivilege') { should match_array ['*S-1-5-32-544'] }
  end
end

control 'cis-2.3.1.1' do
  title 'Ensure \'Accounts: Guest account status\' is set to \'Disabled\' (MS only) (Automated)'
  impact 0.0
  tag cis_id: '2.3.1.1'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.1.1): Ensure \'Accounts: Guest account status\' is set to \'Disabled\' (MS only) (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Disabled: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Accounts: Guest account status
end

control 'cis-2.3.1.2' do
  title 'Ensure \'Accounts: Limit local account use of blank passwords to console logon only\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('LimitBlankPasswordUse') { should cmp == 1 }
  end
end

control 'cis-2.3.1.3' do
  title 'Configure \'Accounts: Rename administrator account\' (Automated)'
  impact 0.0
  tag cis_id: '2.3.1.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.1.3): Configure \'Accounts: Rename administrator account\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, configure the following UI path: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Accounts: Rename administrator account
end

control 'cis-2.3.1.4' do
  title 'Configure \'Accounts: Rename guest account\' (Automated)'
  impact 0.0
  tag cis_id: '2.3.1.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.1.4): Configure \'Accounts: Rename guest account\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, configure the following UI path: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Accounts: Rename guest account
end

control 'cis-2.3.2.1' do
  title 'Ensure \'Audit: Force audit policy subcategory settings (Windows Vista or later) to override audit policy category settings\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('SCENoApplyLegacyAuditPolicy') { should cmp == 1 }
  end
end

control 'cis-2.3.2.2' do
  title 'Ensure \'Audit: Shut down system immediately if unable to log security audits\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('CrashOnAuditFail') { should cmp == 0 }
  end
end

control 'cis-2.3.4.1' do
  title 'Ensure \'Devices: Prevent users from installing printer drivers\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.4.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print\\Providers\\LanManServices\\Servers') do
    its('AddPrinterDrivers') { should cmp == 1 }
  end
end

control 'cis-2.3.5.1' do
  title 'Ensure \'Domain controller: Allow server operators to schedule tasks\' is set to \'Disabled\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.5.1'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('SubmitControl') { should cmp == 0 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.5.2' do
  title 'Ensure \'Domain controller: Allow vulnerable Netlogon secure channel connections\' is set to \'Not Configured\' (DC Only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.5.2'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    it { should_not have_property 'VulnerableChannelAllowList' }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.5.3' do
  title 'Ensure \'Domain controller: LDAP server channel binding token requirements\' is set to \'Always\' (DC Only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.5.3'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\NTDS\\Parameters') do
    its('LdapEnforceChannelBinding') { should cmp == 2 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.5.4' do
  title 'Ensure \'Domain controller: LDAP server signing requirements\' is set to \'Require signing\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.5.4'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\NTDS\\Parameters') do
    its('LDAPServerIntegrity') { should cmp == 2 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.5.5' do
  title 'Ensure \'Domain controller: Refuse machine account password changes\' is set to \'Disabled\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.5.5'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('RefusePasswordChange') { should cmp == 0 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.6.1' do
  title 'Ensure \'Domain member: Digitally encrypt or sign secure channel data (always)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.6.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('RequireSignOrSeal') { should cmp == 1 }
  end
end

control 'cis-2.3.6.2' do
  title 'Ensure \'Domain member: Digitally encrypt secure channel data (when possible)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.6.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('SealSecureChannel') { should cmp == 1 }
  end
end

control 'cis-2.3.6.3' do
  title 'Ensure \'Domain member: Digitally sign secure channel data (when possible)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.6.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('SignSecureChannel') { should cmp == 1 }
  end
end

control 'cis-2.3.6.4' do
  title 'Ensure \'Domain member: Disable machine account password changes\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.6.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('DisablePasswordChange') { should cmp == 0 }
  end
end

control 'cis-2.3.6.5' do
  title 'Ensure \'Domain member: Maximum machine account password age\' is set to \'30 or fewer days, but not 0\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.6.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('MaximumPasswordAge') { should cmp >= 1 }
    its('MaximumPasswordAge') { should cmp <= 30 }
  end
end

control 'cis-2.3.6.6' do
  title 'Ensure \'Domain member: Require strong (Windows 2000 or later) session key\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.6.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('RequireStrongKey') { should cmp == 1 }
  end
end

control 'cis-2.3.7.1' do
  title 'Ensure \'Interactive logon: Do not require CTRL+ALT+DEL\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '2.3.7.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('DisableCAD') { should cmp == 0 }
  end
end

control 'cis-2.3.7.2' do
  title 'Ensure \'Interactive logon: Don\'t display last signed-in\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.7.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('DontDisplayLastUserName') { should cmp == 1 }
  end
end

control 'cis-2.3.7.3' do
  title 'Ensure \'Interactive logon: Machine inactivity limit\' is set to \'900 or fewer second(s), but not 0\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.7.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('InactivityTimeoutSecs') { should cmp >= 1 }
    its('InactivityTimeoutSecs') { should cmp <= 900 }
  end
end

control 'cis-2.3.7.4' do
  title 'Configure \'Interactive logon: Message text for users attempting to log on\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.7.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    # REVIEW: organization-specific value -- benchmark prescribes: text
    it { should have_property 'LegalNoticeText' }
  end
end

control 'cis-2.3.7.5' do
  title 'Configure \'Interactive logon: Message title for users attempting to log on\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.7.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    # REVIEW: organization-specific value -- benchmark prescribes: text
    it { should have_property 'LegalNoticeCaption' }
  end
end

control 'cis-2.3.7.6' do
  title 'Ensure \'Interactive logon: Number of previous logons to cache (in case domain controller is not available)\' is set to \'4 or fewer logon(s)\' (MS only) (Automated)'
  impact 0.7
  tag cis_id: '2.3.7.6'
  tag level: ['L2']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\WindowsNT\\CurrentVersion\\Winlogon') do
    its('CachedLogonsCount') { should cmp >= 0 }
    its('CachedLogonsCount') { should cmp <= 4 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-2.3.7.7' do
  title 'Ensure \'Interactive logon: Prompt user to change password before expiration\' is set to \'between 5 and 14 days\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.7.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\WindowsNT\\CurrentVersion\\Winlogon') do
    its('PasswordExpiryWarning') { should cmp >= 5 }
    its('PasswordExpiryWarning') { should cmp <= 14 }
  end
end

control 'cis-2.3.7.8' do
  title 'Ensure \'Interactive logon: Require Domain Controller Authentication to unlock workstation\' is set to \'Enabled\' (MS only) (Automated)'
  impact 0.0
  tag cis_id: '2.3.7.8'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.7.8): Ensure \'Interactive logon: Require Domain Controller Authentication to unlock workstation\' is set to \'Enabled\' (MS only) (Automated)'
  end
  # Remediation guidance: To implement the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Interactive logon: Require Domain Controller Authentication to unlock workstation
end

control 'cis-2.3.7.9' do
  title 'Ensure \'Interactive logon: Smart card removal behavior\' is set to \'Lock Workstation\' or higher (Automated)'
  impact 0.5
  tag cis_id: '2.3.7.9'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\WindowsNT\\CurrentVersion\\Winlogon') do
    its('ScRemoveOption') { should be_in [1, 2, 3] }
  end
end

control 'cis-2.3.8.1' do
  title 'Ensure \'Microsoft network client: Digitally sign communications (always)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.8.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters') do
    its('RequireSecuritySignature') { should cmp == 1 }
  end
end

control 'cis-2.3.8.2' do
  title 'Ensure \'Microsoft network client: Send unencrypted password to third-party SMB servers\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.8.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanWorkstation\\Parameters') do
    its('EnablePlainTextPassword') { should cmp == 0 }
  end
end

control 'cis-2.3.9.1' do
  title 'Ensure \'Microsoft network server: Amount of idle time required before suspending session\' is set to \'15 or fewer minute(s)\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.9.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    its('AutoDisconnect') { should cmp >= 0 }
    its('AutoDisconnect') { should cmp <= 15 }
  end
end

control 'cis-2.3.9.2' do
  title 'Ensure \'Microsoft network server: Digitally sign communications (always)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.9.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    its('RequireSecuritySignature') { should cmp == 1 }
  end
end

control 'cis-2.3.9.3' do
  title 'Ensure \'Microsoft network server: Disconnect clients when logon hours expire\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.9.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    its('enableforcedlogoff') { should cmp == 1 }
  end
end

control 'cis-2.3.9.4' do
  title 'Ensure \'Microsoft network server: Server SPN target name validation level\' is set to \'Accept if provided by client\' or higher (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.9.4'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    its('SMBServerNameHardeningLevel') { should be_in [1, 2] }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-2.3.10.1' do
  title 'Ensure \'Network access: Allow anonymous SID/Name translation\' is set to \'Disabled\' (Automated)'
  impact 0.0
  tag cis_id: '2.3.10.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.10.1): Ensure \'Network access: Allow anonymous SID/Name translation\' is set to \'Disabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Disabled: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Network access: Allow anonymous SID/Name translation
end

control 'cis-2.3.10.2' do
  title 'Ensure \'Network access: Do not allow anonymous enumeration of SAM accounts\' is set to \'Enabled\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.2'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('RestrictAnonymousSAM') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-2.3.10.3' do
  title 'Ensure \'Network access: Do not allow anonymous enumeration of SAM accounts and shares\' is set to \'Enabled\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.3'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('RestrictAnonymous') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-2.3.10.4' do
  title 'Ensure \'Network access: Do not allow storage of passwords and credentials for network authentication\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '2.3.10.4'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('DisableDomainCreds') { should cmp == 1 }
  end
end

control 'cis-2.3.10.5' do
  title 'Ensure \'Network access: Let Everyone permissions apply to anonymous users\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('EveryoneIncludesAnonymous') { should cmp == 0 }
  end
end

control 'cis-2.3.10.6' do
  title 'Ensure \'Network access: Named Pipes that can be accessed anonymously\' is configured (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.6'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    its('NullSessionPipes') { should cmp 'LSARPC,NETLOGON,SAMR' }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.10.7' do
  title 'Ensure \'Network access: Named Pipes that can be accessed anonymously\' is configured (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.7'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    # REVIEW: organization-specific value -- benchmark prescribes: blank (i.e. None) or BROWSER (when the legacy Computer
    it { should have_property 'NullSessionPipes' }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-2.3.10.8' do
  title 'Ensure \'Network access: Remotely accessible registry paths\' is configured (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.8'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\SecurePipeServers\\Winreg\\AllowedExactPaths') do
    # REVIEW: organization-specific value -- benchmark prescribes: System\CurrentControlSet\Control\ProductOptions,System\CurrentControlS
    it { should have_property 'Machine' }
  end
end

control 'cis-2.3.10.9' do
  title 'Ensure \'Network access: Remotely accessible registry paths and sub-paths\' is configured (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.9'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\SecurePipeServers\\Winreg\\AllowedPaths') do
    # REVIEW: organization-specific value -- benchmark prescribes: System\CurrentControlSet\Control\Print\Printers,System\CurrentControlS
    it { should have_property 'Machine' }
  end
end

control 'cis-2.3.10.10' do
  title 'Ensure \'Network access: Restrict anonymous access to Named Pipes and Shares\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '2.3.10.10'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.10.10): Ensure \'Network access: Restrict anonymous access to Named Pipes and Shares\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Network access: Restrict anonymous access to Named Pipes and Shares
end

control 'cis-2.3.10.11' do
  title 'Ensure \'Network access: Restrict clients allowed to make remote calls to SAM\' is set to \'Administrators: Remote Access: Allow\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.11'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    # REVIEW: organization-specific value -- benchmark prescribes: O:BAG:BAD:(A;;RC;;;BA)
    it { should have_property 'restrictremotesam' }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-2.3.10.12' do
  title 'Ensure \'Network access: Shares that can be accessed anonymously\' is set to \'None\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.12'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanManServer\\Parameters') do
    it { should_not have_property 'NullSessionShares' }
  end
end

control 'cis-2.3.10.13' do
  title 'Ensure \'Network access: Sharing and security model for local accounts\' is set to \'Classic - local users authenticate as themselves\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.10.13'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('ForceGuest') { should cmp == 0 }
  end
end

control 'cis-2.3.11.1' do
  title 'Ensure \'Network security: Allow Local System to use computer identity for NTLM\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('UseMachineId') { should cmp == 1 }
  end
end

control 'cis-2.3.11.2' do
  title 'Ensure \'Network security: Allow LocalSystem NULL session fallback\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\MSV1_0') do
    its('AllowNullSessionFallback') { should cmp == 0 }
  end
end

control 'cis-2.3.11.3' do
  title 'Ensure \'Network Security: Allow PKU2U authentication requests to this computer to use online identities\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\pku2u') do
    its('AllowOnlineID') { should cmp == 0 }
  end
end

control 'cis-2.3.11.4' do
  title 'Ensure \'Network security: Configure encryption types allowed for Kerberos\' is set to \'AES128_HMAC_SHA1, AES256_HMAC_SHA1, Future encryption types\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\Kerberos\\Parameters') do
    its('SupportedEncryptionTypes') { should cmp == 2147483640 }
  end
end

control 'cis-2.3.11.5' do
  title 'Ensure \'Network security: Do not store LAN Manager hash value on next password change\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('NoLMHash') { should cmp == 1 }
  end
end

control 'cis-2.3.11.6' do
  title 'Ensure \'Network security: Force logoff when logon hours expire\' is set to \'Enabled\' (Manual)'
  impact 0.0
  tag cis_id: '2.3.11.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.11.6): Ensure \'Network security: Force logoff when logon hours expire\' is set to \'Enabled\' (Manual)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled. Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\Network security: Force logoff when logon hours expire
end

control 'cis-2.3.11.7' do
  title 'Ensure \'Network security: LAN Manager authentication level\' is set to \'Send NTLMv2 response only. Refuse LM & NTLM\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa') do
    its('LmCompatibilityLevel') { should cmp == 5 }
  end
end

control 'cis-2.3.11.8' do
  title 'Ensure \'Network security: LDAP client signing requirements\' is set to \'Negotiate signing\' or higher (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.8'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LDAP') do
    its('LDAPClientIntegrity') { should be_in [1, 2] }
  end
end

control 'cis-2.3.11.9' do
  title 'Ensure \'Network security: Minimum session security for NTLM SSP based (including secure RPC) clients\' is set to \'Require NTLMv2 session security, Require 128-bit encryption\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.9'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\MSV1_0') do
    its('NTLMMinClientSec') { should cmp == 537395200 }
  end
end

control 'cis-2.3.11.10' do
  title 'Ensure \'Network security: Minimum session security for NTLM SSP based (including secure RPC) servers\' is set to \'Require NTLMv2 session security, Require 128-bit encryption\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.10'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\MSV1_0') do
    its('NTLMMinServerSec') { should cmp == 537395200 }
  end
end

control 'cis-2.3.11.11' do
  title 'Ensure \'Network security: Restrict NTLM: Audit Incoming NTLM Traffic\' is set to \'Enable auditing for all accounts\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.11'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\MSV1_0') do
    its('AuditReceivingNTLMTraffic') { should cmp == 2 }
  end
end

control 'cis-2.3.11.12' do
  title 'Ensure \'Network security: Restrict NTLM: Audit NTLM authentication in this domain\' is set to \'Enable all\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.12'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Netlogon\\Parameters') do
    its('AuditNTLMInDomain') { should cmp == 7 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-2.3.11.13' do
  title 'Ensure \'Network security: Restrict NTLM: Outgoing NTLM traffic to remote servers\' is set to \'Audit all\' or higher (Automated)'
  impact 0.5
  tag cis_id: '2.3.11.13'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Lsa\\MSV1_0') do
    its('RestrictSendingNTLMTraffic') { should be_in [1, 2] }
  end
end

control 'cis-2.3.13.1' do
  title 'Ensure \'Shutdown: Allow system to be shut down without having to log on\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.13.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('ShutdownWithoutLogon') { should cmp == 0 }
  end
end

control 'cis-2.3.15.1' do
  title 'Ensure \'System objects: Require case insensitivity for non-Windows subsystems\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.15.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\SessionManager\\Kernel') do
    its('ObCaseInsensitive') { should cmp == 1 }
  end
end

control 'cis-2.3.15.2' do
  title 'Ensure \'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '2.3.15.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.15.2): Ensure \'System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\System objects: Strengthen default permissions of internal system objects (e.g. Symbolic Links)
end

control 'cis-2.3.17.1' do
  title 'Ensure \'User Account Control: Admin Approval Mode for the Built-in Administrator account\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('FilterAdministratorToken') { should cmp == 1 }
  end
end

control 'cis-2.3.17.2' do
  title 'Ensure \'User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode\' is set to \'Prompt for consent on the secure desktop\' or higher (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('ConsentPromptBehaviorAdmin') { should be_in [1, 2] }
  end
end

control 'cis-2.3.17.3' do
  title 'Ensure \'User Account Control: Behavior of the elevation prompt for standard users\' is set to \'Automatically deny elevation requests\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('ConsentPromptBehaviorUser') { should cmp == 0 }
  end
end

control 'cis-2.3.17.4' do
  title 'Ensure \'User Account Control: Detect application installations and prompt for elevation\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('EnableInstallerDetection') { should cmp == 1 }
  end
end

control 'cis-2.3.17.5' do
  title 'Ensure \'User Account Control: Only elevate UIAccess applications that are installed in secure locations\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('EnableSecureUIAPaths') { should cmp == 1 }
  end
end

control 'cis-2.3.17.6' do
  title 'Ensure \'User Account Control: Run all administrators in Admin Approval Mode\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('EnableLUA') { should cmp == 1 }
  end
end

control 'cis-2.3.17.7' do
  title 'Ensure \'User Account Control: Switch to the secure desktop when prompting for elevation\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '2.3.17.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('PromptOnSecureDesktop') { should cmp == 1 }
  end
end

control 'cis-2.3.17.8' do
  title 'Ensure \'User Account Control: Virtualize file and registry write failures to per-user locations\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '2.3.17.8'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (2.3.17.8): Ensure \'User Account Control: Virtualize file and registry write failures to per-user locations\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Windows Settings\Security Settings\Local Policies\Security Options\User Account Control: Virtualize file and registry write failures to per-user locations
end
