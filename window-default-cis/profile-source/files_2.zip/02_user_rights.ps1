<#  CIS Windows Server 2022 v5.0.0 - Section 2.2 User Rights Assignment (secedit)
    Role-aware: pass -ServerRole member_server | domain_controller #>
function Set-CISUserRights {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [ValidateSet("member_server","domain_controller")]
        [string]$ServerRole = "member_server",
        [string]$BackupDir
    )
    Write-CISLog "Section 2.2 - User Rights Assignment (role: $ServerRole)"

    if ($ServerRole -eq "domain_controller") {
        $rights = @(
        "SeAssignPrimaryTokenPrivilege = *S-1-5-19,*S-1-5-20"   # 2.2.44
        "SeAuditPrivilege = *S-1-5-19,*S-1-5-20"   # 2.2.30
        "SeBackupPrivilege = *S-1-5-32-544"   # 2.2.11
        "SeBatchLogonRight = *S-1-5-32-544"   # 2.2.36
        "SeCreateGlobalPrivilege = *S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6"   # 2.2.15
        "SeCreatePagefilePrivilege = *S-1-5-32-544"   # 2.2.13
        "SeCreatePermanentPrivilege = "   # 2.2.16
        "SeCreateSymbolicLinkPrivilege = *S-1-5-32-544"   # 2.2.17
        "SeCreateTokenPrivilege = "   # 2.2.14
        "SeDebugPrivilege = *S-1-5-32-544"   # 2.2.19
        "SeDenyBatchLogonRight = *S-1-5-32-546"   # 2.2.22
        "SeDenyInteractiveLogonRight = *S-1-5-32-546"   # 2.2.24
        "SeDenyNetworkLogonRight = *S-1-5-32-546"   # 2.2.20
        "SeDenyRemoteInteractiveLogonRight = *S-1-5-32-546"   # 2.2.25
        "SeDenyServiceLogonRight = *S-1-5-32-546"   # 2.2.23
        "SeEnableDelegationPrivilege = *S-1-5-32-544"   # 2.2.27
        "SeImpersonatePrivilege = *S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6"   # 2.2.31
        "SeIncreaseBasePriorityPrivilege = *S-1-5-32-544,*S-1-5-90-0"   # 2.2.33
        "SeIncreaseQuotaPrivilege = *S-1-5-32-544,*S-1-5-19,*S-1-5-20"   # 2.2.6
        "SeInteractiveLogonRight = *S-1-5-32-544,*S-1-5-9"   # 2.2.7
        "SeLoadDriverPrivilege = *S-1-5-32-544"   # 2.2.34
        "SeLockMemoryPrivilege = "   # 2.2.35
        "SeMachineAccountPrivilege = *S-1-5-32-544"   # 2.2.5
        "SeManageVolumePrivilege = *S-1-5-32-544"   # 2.2.41
        "SeNetworkLogonRight = *S-1-5-32-544,*S-1-5-11,*S-1-5-9"   # 2.2.2
        "SeProfileSingleProcessPrivilege = *S-1-5-32-544"   # 2.2.42
        "SeRelabelPrivilege = "   # 2.2.39
        "SeRemoteInteractiveLogonRight = *S-1-5-32-544"   # 2.2.9
        "SeRemoteShutdownPrivilege = *S-1-5-32-544"   # 2.2.29
        "SeRestorePrivilege = *S-1-5-32-544"   # 2.2.45
        "SeSecurityPrivilege = *S-1-5-32-544"   # 2.2.37
        "SeShutdownPrivilege = *S-1-5-32-544"   # 2.2.46
        "SeSyncAgentPrivilege = "   # 2.2.47
        "SeSystemEnvironmentPrivilege = *S-1-5-32-544"   # 2.2.40
        "SeSystemProfilePrivilege = *S-1-5-32-544,*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420"   # 2.2.43
        "SeSystemtimePrivilege = *S-1-5-32-544,*S-1-5-19"   # 2.2.12
        "SeTakeOwnershipPrivilege = *S-1-5-32-544"   # 2.2.48
        "SeTcbPrivilege = "   # 2.2.4
        "SeTrustedCredManAccessPrivilege = "   # 2.2.1
        )
    } else {
        $rights = @(
        "SeAssignPrimaryTokenPrivilege = *S-1-5-19,*S-1-5-20"   # 2.2.44
        "SeAuditPrivilege = *S-1-5-19,*S-1-5-20"   # 2.2.30
        "SeBackupPrivilege = *S-1-5-32-544"   # 2.2.11
        "SeBatchLogonRight = *S-1-5-32-544"   # 2.2.36
        "SeCreateGlobalPrivilege = *S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6"   # 2.2.15
        "SeCreatePagefilePrivilege = *S-1-5-32-544"   # 2.2.13
        "SeCreatePermanentPrivilege = "   # 2.2.16
        "SeCreateSymbolicLinkPrivilege = *S-1-5-32-544,*S-1-5-83-0"   # 2.2.18
        "SeCreateTokenPrivilege = "   # 2.2.14
        "SeDebugPrivilege = *S-1-5-32-544"   # 2.2.19
        "SeDenyBatchLogonRight = *S-1-5-32-546"   # 2.2.22
        "SeDenyInteractiveLogonRight = *S-1-5-32-546"   # 2.2.24
        "SeDenyNetworkLogonRight = *S-1-5-32-546,*S-1-5-114"   # 2.2.21
        "SeDenyRemoteInteractiveLogonRight = *S-1-5-32-546,*S-1-5-113"   # 2.2.26
        "SeDenyServiceLogonRight = *S-1-5-32-546"   # 2.2.23
        "SeEnableDelegationPrivilege = "   # 2.2.28
        "SeImpersonatePrivilege = *S-1-5-32-544,*S-1-5-19,*S-1-5-20,*S-1-5-6"   # 2.2.32
        "SeIncreaseBasePriorityPrivilege = *S-1-5-32-544,*S-1-5-90-0"   # 2.2.33
        "SeIncreaseQuotaPrivilege = *S-1-5-32-544,*S-1-5-19,*S-1-5-20"   # 2.2.6
        "SeInteractiveLogonRight = *S-1-5-32-544"   # 2.2.8
        "SeLoadDriverPrivilege = *S-1-5-32-544"   # 2.2.34
        "SeLockMemoryPrivilege = "   # 2.2.35
        "SeMachineAccountPrivilege = *S-1-5-32-544"   # 2.2.5
        "SeManageVolumePrivilege = *S-1-5-32-544"   # 2.2.41
        "SeNetworkLogonRight = *S-1-5-32-544,*S-1-5-11"   # 2.2.3
        "SeProfileSingleProcessPrivilege = *S-1-5-32-544"   # 2.2.42
        "SeRelabelPrivilege = "   # 2.2.39
        "SeRemoteInteractiveLogonRight = *S-1-5-32-544,*S-1-5-32-555"   # 2.2.10
        "SeRemoteShutdownPrivilege = *S-1-5-32-544"   # 2.2.29
        "SeRestorePrivilege = *S-1-5-32-544"   # 2.2.45
        "SeSecurityPrivilege = *S-1-5-32-544"   # 2.2.38
        "SeShutdownPrivilege = *S-1-5-32-544"   # 2.2.46
        "SeSyncAgentPrivilege = "   # 2.2.47
        "SeSystemEnvironmentPrivilege = *S-1-5-32-544"   # 2.2.40
        "SeSystemProfilePrivilege = *S-1-5-32-544,*S-1-5-80-3139157870-2983391045-3678747466-658725712-1809340420"   # 2.2.43
        "SeSystemtimePrivilege = *S-1-5-32-544,*S-1-5-19"   # 2.2.12
        "SeTakeOwnershipPrivilege = *S-1-5-32-544"   # 2.2.48
        "SeTcbPrivilege = "   # 2.2.4
        "SeTrustedCredManAccessPrivilege = "   # 2.2.1
        )
    }

    $inf = @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
[Privilege Rights]
$($rights -join "`r`n")
"@
    $tmp = Join-Path $env:TEMP "cis_userrights.inf"
    $sdb = Join-Path $env:TEMP "cis_userrights.sdb"
    $inf | Out-File -FilePath $tmp -Encoding unicode -Force
    if ($PSCmdlet.ShouldProcess("Local Security Policy", "Apply CIS user rights assignments")) {
        secedit /configure /db $sdb /cfg $tmp /areas USER_RIGHTS /quiet | Out-Null
        Write-CISLog "  Applied user rights via secedit (exit $LASTEXITCODE)"
    }
    Remove-Item $tmp,$sdb -ErrorAction SilentlyContinue
}
