# encoding: UTF-8
# CIS Microsoft Windows Server 2022 Benchmark v5.0.0
# Section 19 - Administrative Templates (User)
# Auto-generated; verify organization-specific (REVIEW) controls.

control 'cis-19.5.1.1' do
  title 'Ensure \'Turn off toast notifications on the lock screen\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.5.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.5.1.1 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\Windows\\CurrentVersion\\PushNotifications") do
          its('NoToastApplicationNotificationOnLockScreen') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.6.6.1.1' do
  title 'Ensure \'Turn off Help Experience Improvement Program\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '19.6.6.1.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.6.6.1.1 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\Assistance\\Client\\1.0") do
          its('NoImplicitFeedback') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.7.5.1' do
  title 'Ensure \'Do not preserve zone information in file attachments\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.7.5.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.5.1 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Attachments") do
          its('SaveZoneInformation') { should cmp == 2 }
      end
    end
  end
end

control 'cis-19.7.5.2' do
  title 'Ensure \'Notify antivirus programs when opening attachments\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.7.5.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.5.2 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Attachments") do
          its('ScanWithAntiVirus') { should cmp == 3 }
      end
    end
  end
end

control 'cis-19.7.8.1' do
  title 'Ensure \'Configure Windows spotlight on lock screen\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.7.8.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.8.1 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\Windows\\CloudContent") do
          its('ConfigureWindowsSpotlight') { should cmp == 2 }
      end
    end
  end
end

control 'cis-19.7.8.2' do
  title 'Ensure \'Do not suggest third-party content in Windows spotlight\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.7.8.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.8.2 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\Windows\\CloudContent") do
          its('DisableThirdPartySuggestions') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.7.8.3' do
  title 'Ensure \'Do not use diagnostic data for tailored experiences\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '19.7.8.3'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.8.3 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\Windows\\CloudContent") do
          its('DisableTailoredExperiencesWithDiagnosticData') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.7.8.4' do
  title 'Ensure \'Turn off all Windows spotlight features\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '19.7.8.4'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.8.4 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\Windows\\CloudContent") do
          its('DisableWindowsSpotlightFeatures') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.7.8.5' do
  title 'Ensure \'Turn off Spotlight collection on Desktop\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.7.8.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.8.5 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent") do
          its('DisableSpotlightCollectionOnDesktop') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.7.26.1' do
  title 'Ensure \'Prevent users from sharing files within their profile.\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '19.7.26.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.26.1 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer") do
          its('NoInplaceSharing') { should cmp == 1 }
      end
    end
  end
end

control 'cis-19.7.46.2.1' do
  title 'Ensure \'Prevent Codec Download\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '19.7.46.2.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry_user'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  user_sids = registry_key('HKEY_USERS').children.map { |c| c[/S-1-5-21-[\d-]+/] }.compact.uniq
  if user_sids.empty?
    describe 'cis-19.7.46.2.1 (per-user)' do
      skip 'No interactive user profiles (S-1-5-21-*) are loaded under HKEY_USERS, so this per-user setting could not be evaluated live. Enforce via Group Policy / the matching remediation, which also writes the .DEFAULT hive for future users.'
    end
  else
    user_sids.each do |sid|
      describe registry_key("HKEY_USERS\\#{sid}\\Software\\Policies\\Microsoft\\WindowsMediaPlayer") do
          its('PreventCodecDownload') { should cmp == 1 }
      end
    end
  end
end
