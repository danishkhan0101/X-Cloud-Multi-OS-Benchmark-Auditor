# encoding: UTF-8
# CIS Microsoft Windows Server 2022 Benchmark v5.0.0
# Section 18 - Administrative Templates (Computer)
# Auto-generated; verify organization-specific (REVIEW) controls.

control 'cis-18.1.1.1' do
  title 'Ensure \'Prevent enabling lock screen camera\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.1.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Personalization') do
    its('NoLockScreenCamera') { should cmp == 1 }
  end
end

control 'cis-18.1.1.2' do
  title 'Ensure \'Prevent enabling lock screen slide show\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.1.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Personalization') do
    its('NoLockScreenSlideshow') { should cmp == 1 }
  end
end

control 'cis-18.1.2.2' do
  title 'Ensure \'Allow users to enable online speech recognition services\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.1.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\InputPersonalization') do
    its('AllowInputPersonalization') { should cmp == 0 }
  end
end

control 'cis-18.1.3' do
  title 'Ensure \'Allow Online Tips\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.1.3'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('AllowOnlineTips') { should cmp == 0 }
  end
end

control 'cis-18.4.1' do
  title 'Ensure \'Apply UAC restrictions to local accounts on network logons\' is set to \'Enabled\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '18.4.1'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('LocalAccountTokenFilterPolicy') { should cmp == 0 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.4.2' do
  title 'Ensure \'Configure SMB v1 client driver\' is set to \'Enabled: Disable driver (recommended)\' (Automated)'
  impact 0.5
  tag cis_id: '18.4.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\mrxsmb10') do
    its('Start') { should cmp == 4 }
  end
end

control 'cis-18.4.3' do
  title 'Ensure \'Configure SMB v1 server\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.4.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters') do
    its('SMB1') { should cmp == 0 }
  end
end

control 'cis-18.4.4' do
  title 'Ensure \'Enable Certificate Padding\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.4.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography\\Wintrust\\Config') do
    its('EnableCertPaddingCheck') { should cmp == 1 }
  end
end

control 'cis-18.4.5' do
  title 'Ensure \'Enable Structured Exception Handling Overwrite Protection (SEHOP)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.4.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\SessionManager\\kernel') do
    its('DisableExceptionChainValidation') { should cmp == 0 }
  end
end

control 'cis-18.4.6' do
  title 'Ensure \'NetBT NodeType configuration\' is set to \'Enabled: P-node (recommended)\' (Automated)'
  impact 0.5
  tag cis_id: '18.4.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\NetBT\\Parameters') do
    its('NodeType') { should cmp == 2 }
  end
end

control 'cis-18.5.1' do
  title 'Ensure \'MSS: (AutoAdminLogon) Enable Automatic Logon\' is set to \'Disabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.5.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.5.1): Ensure \'MSS: (AutoAdminLogon) Enable Automatic Logon\' is set to \'Disabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Disabled: Computer Configuration\Policies\Administrative Templates\MSS (Legacy)\MSS: (AutoAdminLogon) Enable Automatic Logon Note: This Group Policy path does not exist by default. An additional Group Policy template (MS
end

control 'cis-18.5.2' do
  title 'Ensure \'MSS: (DisableIPSourceRouting IPv6) IP source routing protection level\' is set to \'Enabled: Highest protection, source routing is completely disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.5.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters') do
    its('DisableIPSourceRouting') { should cmp == 2 }
  end
end

control 'cis-18.5.3' do
  title 'Ensure \'MSS: (DisableIPSourceRouting) IP source routing protection level\' is set to \'Enabled: Highest protection, source routing is completely disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.5.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters') do
    its('DisableIPSourceRouting') { should cmp == 2 }
  end
end

control 'cis-18.5.4' do
  title 'Ensure \'MSS: (EnableICMPRedirect) Allow ICMP redirects to override OSPF generated routes\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.5.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters') do
    its('EnableICMPRedirect') { should cmp == 0 }
  end
end

control 'cis-18.5.5' do
  title 'Ensure \'MSS: (KeepAliveTime) How often keep-alive packets are sent in milliseconds\' is set to \'Enabled: 300,000 or 5 minutes\' (Automated)'
  impact 0.7
  tag cis_id: '18.5.5'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters') do
    its('KeepAliveTime') { should cmp == 300000 }
  end
end

control 'cis-18.5.6' do
  title 'Ensure \'MSS: (NoNameReleaseOnDemand) Allow the computer to ignore NetBIOS name release requests except from WINS servers\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.5.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\NetBT\\Parameters') do
    its('NoNameReleaseOnDemand') { should cmp == 1 }
  end
end

control 'cis-18.5.7' do
  title 'Ensure \'MSS: (PerformRouterDiscovery) Allow IRDP to detect and configure Default Gateway addresses\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.5.7'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters') do
    its('PerformRouterDiscovery') { should cmp == 0 }
  end
end

control 'cis-18.5.8' do
  title 'Ensure \'MSS: (SafeDllSearchMode) Enable Safe DLL search mode\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.5.8'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.5.8): Ensure \'MSS: (SafeDllSearchMode) Enable Safe DLL search mode\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\MSS (Legacy)\MSS: (SafeDllSearchMode) Enable Safe DLL search mode Note: This Group Policy path does not exist by default. An additional Group Policy templ
end

control 'cis-18.5.9' do
  title 'Ensure \'MSS: (TcpMaxDataRetransmissions IPv6) How many times unacknowledged data is retransmitted\' is set to \'Enabled: 3\' (Automated)'
  impact 0.7
  tag cis_id: '18.5.9'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\TCPIP6\\Parameters') do
    its('TcpMaxDataRetransmissions') { should cmp == 3 }
  end
end

control 'cis-18.5.10' do
  title 'Ensure \'MSS: (TcpMaxDataRetransmissions) How many times unacknowledged data is retransmitted\' is set to \'Enabled: 3\' (Automated)'
  impact 0.7
  tag cis_id: '18.5.10'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters') do
    its('TcpMaxDataRetransmissions') { should cmp == 3 }
  end
end

control 'cis-18.5.11' do
  title 'Ensure \'MSS: (WarningLevel) Percentage threshold for the security event log at which the system will generate a warning\' is set to \'Enabled: 90% or less\' (Automated)'
  impact 0.5
  tag cis_id: '18.5.11'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Eventlog\\Security') do
    its('WarningLevel') { should cmp == 90 }
  end
end

control 'cis-18.6.4.1' do
  title 'Ensure \'Configure multicast DNS (mDNS) protocol\' is set to \'Disabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.6.4.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.6.4.1): Ensure \'Configure multicast DNS (mDNS) protocol\' is set to \'Disabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Disabled: Computer Configuration\Policies\Administrative Templates\Network\DNS Client\Configure multicast DNS (mDNS) protocol Note: This Group Policy path is provided by the Group Policy template DnsClient.admx/adml that
end

control 'cis-18.6.4.2' do
  title 'Ensure \'Configure NetBIOS settings\' is set to \'Enabled: Disable NetBIOS name resolution on public networks\' (Automated)'
  impact 0.0
  tag cis_id: '18.6.4.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.6.4.2): Ensure \'Configure NetBIOS settings\' is set to \'Enabled: Disable NetBIOS name resolution on public networks\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Disable NetBIOS name resolution on public networks: Computer Configuration\Policies\Administrative Templates\Network\DNS Client\Configure NetBIOS settings Note: This Group Policy path may not exist by default. I
end

control 'cis-18.6.4.3' do
  title 'Ensure \'Turn off default IPv6 DNS Servers\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.4.3'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsNT\\DNSClient') do
    its('DisableIPv6DefaultDnsServers') { should cmp == 1 }
  end
end

control 'cis-18.6.4.4' do
  title 'Ensure \'Turn off multicast name resolution\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.6.4.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.6.4.4): Ensure \'Turn off multicast name resolution\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Network\DNS Client\Turn off multicast name resolution Note: This Group Policy path may not exist by default. It is provided by the Group Policy template D
end

control 'cis-18.6.5.1' do
  title 'Ensure \'Enable Font Providers\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.5.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('EnableFontProviders') { should cmp == 0 }
  end
end

control 'cis-18.6.7.1' do
  title 'Ensure \'Mandate the minimum version of SMB\' is set to \'Enabled: 3.1.1\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.7.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\LanmanServer') do
    its('MinSmb2Dialect') { should cmp == 785 }
  end
end

control 'cis-18.6.8.1' do
  title 'Ensure \'Enable insecure guest logons\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.8.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\LanmanWorkstation') do
    its('AllowInsecureGuestAuth') { should cmp == 0 }
  end
end

control 'cis-18.6.8.2' do
  title 'Ensure \'Require Encryption\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.8.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\LanmanWorkstation') do
    its('RequireEncryption') { should cmp == 1 }
  end
end

control 'cis-18.6.9.1' do
  title 'Ensure \'Turn on Mapper I/O (LLTDIO) driver\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.9.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\LLTD') do
    its('AllowLLTDIOOnDomain') { should cmp == 0 }
  end
end

control 'cis-18.6.9.2' do
  title 'Ensure \'Turn on Responder (RSPNDR) driver\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.9.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\LLTD') do
    its('AllowRspndrOnDomain') { should cmp == 0 }
  end
end

control 'cis-18.6.10.2' do
  title 'Ensure \'Turn off Microsoft Peer-to-Peer Networking Services\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.10.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Peernet') do
    its('Disabled') { should cmp == 1 }
  end
end

control 'cis-18.6.11.2' do
  title 'Ensure \'Prohibit installation and configuration of Network Bridge on your DNS domain network\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.11.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\NetworkConnections') do
    its('NC_AllowNetBridge_NLA') { should cmp == 0 }
  end
end

control 'cis-18.6.11.3' do
  title 'Ensure \'Prohibit use of Internet Connection Sharing on your DNS domain network\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.11.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\NetworkConnections') do
    its('NC_ShowSharedAccessUI') { should cmp == 0 }
  end
end

control 'cis-18.6.11.4' do
  title 'Ensure \'Require domain users to elevate when setting a network\'s location\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.11.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\NetworkConnections') do
    its('NC_StdDomainUserSetLocation') { should cmp == 1 }
  end
end

control 'cis-18.6.14.1' do
  title 'Ensure \'Hardened UNC Paths\' is set to \'Enabled, with "Require Mutual Authentication", "Require Integrity", and "Require Privacy" set for all NETLOGON and SYSVOL shares\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.14.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\NetworkProvider\\HardenedPaths') do
    # REVIEW: organization-specific value -- benchmark prescribes: RequireMutualAuthentication=1, RequireIntegrity=1,
    it { should have_property '\\\\*\\NETLOGON' }
  end
end

control 'cis-18.6.20.1' do
  title 'Ensure \'Configuration of wireless settings using Windows Connect Now\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.20.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WCN\\Registrars') do
    its('EnableRegistrars') { should cmp == 0 }
  end
end

control 'cis-18.6.20.2' do
  title 'Ensure \'Prohibit access of the Windows Connect Now wizards\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.6.20.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WCN\\UI') do
    its('DisableWcnUi') { should cmp == 1 }
  end
end

control 'cis-18.6.21.1' do
  title 'Ensure \'Minimize the number of simultaneous connections to the Internet or a Windows Domain\' is set to \'Enabled: 3 = Prevent Wi-Fi when on Ethernet\' (Automated)'
  impact 0.5
  tag cis_id: '18.6.21.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WcmSvc\\GroupPolicy') do
    its('fMinimizeConnections') { should cmp == 3 }
  end
end

control 'cis-18.6.21.2' do
  title 'Ensure \'Prohibit connection to non-domain networks when connected to domain authenticated network\' is set to \'Enabled\' (MS only) (Automated)'
  impact 0.7
  tag cis_id: '18.6.21.2'
  tag level: ['L2']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WcmSvc\\GroupPolicy') do
    its('fBlockNonDomain') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.7.1' do
  title 'Ensure \'Allow Print Spooler to accept client connections\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsNT\\Printers') do
    its('RegisterSpoolerRemoteRpcEndPoint') { should cmp == 2 }
  end
end

control 'cis-18.7.2' do
  title 'Ensure \'Configure Redirection Guard\' is set to \'Enabled: Redirection Guard Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.7.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.7.2): Ensure \'Configure Redirection Guard\' is set to \'Enabled: Redirection Guard Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Redirection Guard Enabled: Computer Configuration\Policies\Administrative Templates\Printers\Configure Redirection Guard Note: This Group Policy path is provided by the Group Policy template Printing.admx/adml t
end

control 'cis-18.7.3' do
  title 'Ensure \'Configure RPC connection settings: Protocol to use for outgoing RPC connections\' is set to \'Enabled: RPC over TCP\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsNT\\Printers\\RPC') do
    its('RpcUseNamedPipeProtocol') { should cmp == 0 }
  end
end

control 'cis-18.7.4' do
  title 'Ensure \'Configure RPC connection settings: Use authentication for outgoing RPC connections\' is set to \'Enabled: Default\' (Automated)'
  impact 0.0
  tag cis_id: '18.7.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.7.4): Ensure \'Configure RPC connection settings: Use authentication for outgoing RPC connections\' is set to \'Enabled: Default\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Default: Computer Configuration\Policies\Administrative Templates\Printers\Configure RPC connection settings: Use authentication for outgoing RPC connections Note: This Group Policy path is provided by the Group
end

control 'cis-18.7.5' do
  title 'Ensure \'Configure RPC listener settings: Protocols to allow for incoming RPC connections\' is set to \'Enabled: RPC over TCP\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsNT\\Printers\\RPC') do
    its('RpcProtocols') { should cmp == 5 }
  end
end

control 'cis-18.7.6' do
  title 'Ensure \'Configure RPC listener settings: Authentication protocol to use for incoming RPC connections:\' is set to \'Enabled: Negotiate\' or higher (Automated)'
  impact 0.0
  tag cis_id: '18.7.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.7.6): Ensure \'Configure RPC listener settings: Authentication protocol to use for incoming RPC connections:\' is set to \'Enabled: Negotiate\' or higher (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Negotiate or Enabled: Kerberos: Computer Configuration\Policies\Administrative Templates\Printers\Configure RPC listener settings: Configure protocol options for incoming RPC connections Note: This Group Policy 
end

control 'cis-18.7.7' do
  title 'Ensure \'Configure RPC over TCP port\' is set to \'Enabled: 0\' (Automated)'
  impact 0.0
  tag cis_id: '18.7.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.7.7): Ensure \'Configure RPC over TCP port\' is set to \'Enabled: 0\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: 0: Computer Configuration\Policies\Administrative Templates\Printers\Configure RPC over TCP port Note: This Group Policy path is provided by the Group Policy template Printing.admx/adml that is included with the
end

control 'cis-18.7.8' do
  title 'Ensure \'Configure RPC packet level privacy setting for incoming connections\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.8'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print') do
    its('RpcAuthnLevelPrivacyEnabled') { should cmp == 1 }
  end
end

control 'cis-18.7.9' do
  title 'Ensure \'Limits print driver installation to Administrators\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.9'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsNT\\Printers\\PointAndPrint') do
    its('RestrictDriverInstallationToAdministrators') { should cmp == 1 }
  end
end

control 'cis-18.7.10' do
  title 'Ensure \'Manage processing of Queue-specific files\' is set to \'Enabled: Limit Queue-specific files to Color profiles\' (Automated)'
  impact 0.0
  tag cis_id: '18.7.10'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.7.10): Ensure \'Manage processing of Queue-specific files\' is set to \'Enabled: Limit Queue-specific files to Color profiles\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Limit Queue-specific files to Color profiles: Computer Configuration\Policies\Administrative Templates\Printers\Manage processing of Queue-specific files Note: This Group Policy path is provided by the Group Pol
end

control 'cis-18.7.11' do
  title 'Ensure \'Point and Print Restrictions: When installing drivers for a new connection\' is set to \'Enabled: Show warning and elevation prompt\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.11'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsNT\\Printers\\PointAndPrint') do
    its('NoWarningNoElevationOnInstall') { should cmp == 0 }
  end
end

control 'cis-18.7.12' do
  title 'Ensure \'Point and Print Restrictions: When updating drivers for an existing connection\' is set to \'Enabled: Show warning and elevation prompt\' (Automated)'
  impact 0.5
  tag cis_id: '18.7.12'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\WindowsNT\\Printers\\PointAndPrint') do
    its('UpdatePromptSettings') { should cmp == 0 }
  end
end

control 'cis-18.8.1.1' do
  title 'Ensure \'Turn off notifications network usage\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.8.1.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CurrentVersion\\PushNotifications') do
    its('NoCloudApplicationNotification') { should cmp == 1 }
  end
end

control 'cis-18.9.3.1' do
  title 'Ensure \'Include command line in process creation events\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.3.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\Audit') do
    its('ProcessCreationIncludeCmdLine_Enabled') { should cmp == 1 }
  end
end

control 'cis-18.9.4.1' do
  title 'Ensure \'Encryption Oracle Remediation\' is set to \'Enabled: Force Updated Clients\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.4.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\CredSSP\\Parameters') do
    its('AllowEncryptionOracle') { should cmp == 0 }
  end
end

control 'cis-18.9.4.2' do
  title 'Ensure \'Remote host allows delegation of non-exportable credentials\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.4.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CredentialsDelegation') do
    its('AllowProtectedCreds') { should cmp == 1 }
  end
end

control 'cis-18.9.5.1' do
  title 'Ensure \'Turn On Virtualization Based Security\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('EnableVirtualizationBasedSecurity') { should cmp == 1 }
  end
end

control 'cis-18.9.5.2' do
  title 'Ensure \'Turn On Virtualization Based Security: Select Platform Security Level\' is set to \'Secure Boot\' or higher (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('RequirePlatformSecurityFeatures') { should be_in [1, 3] }
  end
end

control 'cis-18.9.5.3' do
  title 'Ensure \'Turn On Virtualization Based Security: Virtualization Based Protection of Code Integrity\' is set to \'Enabled with UEFI lock\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('HypervisorEnforcedCodeIntegrity') { should cmp == 1 }
  end
end

control 'cis-18.9.5.4' do
  title 'Ensure \'Turn On Virtualization Based Security: Require UEFI Memory Attributes Table\' is set to \'True (checked)\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('HVCIMATRequired') { should cmp == 1 }
  end
end

control 'cis-18.9.5.5' do
  title 'Ensure \'Turn On Virtualization Based Security: Credential Guard Configuration\' is set to \'Enabled with UEFI lock\' (MS Only) (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.5'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('LsaCfgFlags') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.5.6' do
  title 'Ensure \'Turn On Virtualization Based Security: Credential Guard Configuration\' is set to \'Disabled\' (DC Only) (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.6'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('LsaCfgFlags') { should cmp == 0 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-18.9.5.7' do
  title 'Ensure \'Turn On Virtualization Based Security: Secure Launch Configuration\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.5.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceGuard') do
    its('ConfigureSystemGuardLaunch') { should cmp == 1 }
  end
end

control 'cis-18.9.7.2' do
  title 'Ensure \'Prevent automatic download of applications associated with device metadata\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.7.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DeviceMetadata') do
    its('PreventDeviceMetadataFromNetwork') { should cmp == 1 }
  end
end

control 'cis-18.9.13.1' do
  title 'Ensure \'Boot-Start Driver Initialization Policy\' is set to \'Enabled: Good, unknown and bad but critical\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.13.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Policies\\EarlyLaunch') do
    its('DriverLoadPolicy') { should cmp == 3 }
  end
end

control 'cis-18.9.17.1' do
  title 'Ensure \'Enable / disable CLFS logfile authentication\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.17.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Policies') do
    its('ClfsAuthenticationChecking') { should cmp == 1 }
  end
end

control 'cis-18.9.19.2' do
  title 'Ensure \'Configure security policy processing: Do not apply during periodic background processing\' is set to \'Enabled: FALSE\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.19.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\GroupA4EA-00C04F79F83A}') do
    its('NoBackgroundPolicy') { should cmp == 0 }
  end
end

control 'cis-18.9.19.3' do
  title 'Ensure \'Configure security policy processing: Process even if the Group Policy objects have not changed\' is set to \'Enabled: TRUE\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.19.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\GroupA4EA-00C04F79F83A}') do
    its('NoGPOListChanges') { should cmp == 0 }
  end
end

control 'cis-18.9.19.4' do
  title 'Ensure \'Continue experiences on this device\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.19.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('EnableCdp') { should cmp == 0 }
  end
end

control 'cis-18.9.19.5' do
  title 'Ensure \'Turn off background refresh of Group Policy\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.19.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('DisableBkGndGroupPolicy') { should cmp == 0 }
  end
end

control 'cis-18.9.20.1.1' do
  title 'Ensure \'Turn off downloading of print drivers over HTTP\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.9.20.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.9.20.1.1): Ensure \'Turn off downloading of print drivers over HTTP\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\System\Internet Communication Management\Internet Communication settings\Turn off downloading of print drivers over HTTP Note: This Group Policy path is p
end

control 'cis-18.9.20.1.2' do
  title 'Ensure \'Turn off handwriting personalization data sharing\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\TabletPC') do
    its('PreventHandwritingDataSharing') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.3' do
  title 'Ensure \'Turn off handwriting recognition error reporting\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.3'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\HandwritingErrorReports') do
    its('PreventHandwritingErrorReports') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.4' do
  title 'Ensure \'Turn off Internet Connection Wizard if URL connection is referring to Microsoft.com\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.4'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\InternetWizard') do
    its('ExitOnMSICW') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.5' do
  title 'Ensure \'Turn off Internet download for Web publishing and online ordering wizards\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.20.1.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('NoWebServices') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.6' do
  title 'Ensure \'Turn off printing over HTTP\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.9.20.1.6'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.9.20.1.6): Ensure \'Turn off printing over HTTP\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\System\Internet Communication Management\Internet Communication settings\Turn off printing over HTTP Note: This Group Policy path is provided by the Group
end

control 'cis-18.9.20.1.7' do
  title 'Ensure \'Turn off Registration if URL connection is referring to Microsoft.com\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.7'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\RegistrationControl') do
    its('NoRegistration') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.8' do
  title 'Ensure \'Turn off Search Companion content file updates\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.8'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SearchCompanion') do
    its('DisableContentFileUpdates') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.9' do
  title 'Ensure \'Turn off the "Order Prints" picture task\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.9'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('NoOnlinePrintsWizard') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.10' do
  title 'Ensure \'Turn off the "Publish to Web" task for files and folders\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.10'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('NoPublishingWizard') { should cmp == 1 }
  end
end

control 'cis-18.9.20.1.11' do
  title 'Ensure \'Turn off the Windows Messenger Customer Experience Improvement Program\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.11'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Messenger\\Client') do
    its('CEIP') { should cmp == 2 }
  end
end

control 'cis-18.9.20.1.12' do
  title 'Ensure \'Turn off Windows Customer Experience Improvement Program\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.12'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows') do
    its('CEIPEnable') { should cmp == 0 }
  end
end

control 'cis-18.9.20.1.13' do
  title 'Ensure \'Turn off Windows Error Reporting\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.20.1.13'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsReporting') do
    # REVIEW: organization-specific value -- benchmark prescribes: 0 (DoReport) and 1 (Disabled)
    it { should have_property 'Disabled' }
  end
end

control 'cis-18.9.23.1' do
  title 'Ensure \'Support device authentication using certificate\' is set to \'Enabled: Automatic\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.23.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\kerberos\\parameters') do
    # REVIEW: organization-specific value -- benchmark prescribes: 0 (DevicePKInitBehavior) and 1 (DevicePKInitEnabled)
    it { should have_property 'DevicePKInitBehavior' }
  end
end

control 'cis-18.9.24.1' do
  title 'Ensure \'Enumeration policy for external devices incompatible with Kernel DMA Protection\' is set to \'Enabled: Block All\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.24.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\KernelProtection') do
    its('DeviceEnumerationPolicy') { should cmp == 0 }
  end
end

control 'cis-18.9.26.1' do
  title 'Ensure \'Configure password backup directory\' is set to \'Enabled: Active Directory\' or \'Enabled: Azure Active Directory\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.1'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('BackupDirectory') { should be_in [1, 2] }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.2' do
  title 'Ensure \'Do not allow password expiration time longer than required by policy\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.2'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('PasswordExpirationProtectionEnabled') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.3' do
  title 'Ensure \'Enable password encryption\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.3'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('ADPasswordEncryptionEnabled') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.4' do
  title 'Ensure \'Password Settings: Password Complexity\' is set to \'Enabled: Large letters + small letters + numbers + special characters\' or \'Passphrase\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.4'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('PasswordComplexity') { should be_in [4, 6, 7, 8] }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.5' do
  title 'Ensure \'Password Settings: Password Length\' is set to \'Enabled: 15 or more\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.5'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('PasswordLength') { should cmp == 15 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.6' do
  title 'Ensure \'Password Settings: Password Age (Days)\' is set to \'Enabled: 30 or fewer\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.6'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('PasswordAgeDays') { should cmp == 30 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.7' do
  title 'Ensure \'Post-authentication actions: Grace period (hours)\' is set to \'Enabled: 8 or fewer hours, but not 0\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.7'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('PostAuthenticationResetDelay') { should cmp >= 1 }
    its('PostAuthenticationResetDelay') { should cmp <= 8 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.26.8' do
  title 'Ensure \'Post-authentication actions: Actions\' is set to \'Enabled: Reset the password and logoff the managed account\' or higher (Automated)'
  impact 0.5
  tag cis_id: '18.9.26.8'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\LAPS') do
    its('PostAuthenticationActions') { should be_in [3, 5, 11] }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.27.1' do
  title 'Ensure \'Allow Custom SSPs and APs to be loaded into LSASS\' is set to \'Disabled\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '18.9.27.1'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('AllowCustomSSPsAPs') { should cmp == 0 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-18.9.27.2' do
  title 'Ensure \'Configures LSASS to run as a protected process\' is set to \'Enabled: Enabled with UEFI Lock\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.27.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('RunAsPPL') { should cmp == 1 }
  end
end

control 'cis-18.9.28.1' do
  title 'Ensure \'Disallow copying of user input methods to the system account for sign-in\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.28.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\ControlPanel\\International') do
    its('BlockUserInputMethodsForSignIn') { should cmp == 1 }
  end
end

control 'cis-18.9.29.1' do
  title 'Ensure \'Block user from showing account details on sign-in\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.29.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('BlockUserFromShowingAccountDetailsOnSignin') { should cmp == 1 }
  end
end

control 'cis-18.9.29.2' do
  title 'Ensure \'Do not display network selection UI\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.29.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('DontDisplayNetworkSelectionUI') { should cmp == 1 }
  end
end

control 'cis-18.9.29.3' do
  title 'Ensure \'Do not enumerate connected users on domain- joined computers\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.29.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('DontEnumerateConnectedUsers') { should cmp == 1 }
  end
end

control 'cis-18.9.29.4' do
  title 'Ensure \'Enumerate local users on domain-joined computers\' is set to \'Disabled\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '18.9.29.4'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('EnumerateLocalUsers') { should cmp == 0 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.9.29.5' do
  title 'Ensure \'Turn off app notifications on the lock screen\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.29.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('DisableLockScreenAppNotifications') { should cmp == 1 }
  end
end

control 'cis-18.9.29.6' do
  title 'Ensure \'Turn on convenience PIN sign-in\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.29.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('AllowDomainPINLogon') { should cmp == 0 }
  end
end

control 'cis-18.9.33.1' do
  title 'Ensure \'Allow Clipboard synchronization across devices\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.33.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('AllowCrossDeviceClipboard') { should cmp == 0 }
  end
end

control 'cis-18.9.33.2' do
  title 'Ensure \'Allow upload of User Activities\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.33.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    its('UploadUserActivities') { should cmp == 0 }
  end
end

control 'cis-18.9.35.6.1' do
  title 'Ensure \'Allow network connectivity during connected- standby (on battery)\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.35.6.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Power\\PowerSettings\\f15576e8-98b7-4186-b944-eafa664402d9') do
    its('DCSettingIndex') { should cmp == 0 }
  end
end

control 'cis-18.9.35.6.2' do
  title 'Ensure \'Allow network connectivity during connected- standby (plugged in)\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.35.6.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Power\\PowerSettings\\f15576e8-98b7-4186-b944-eafa664402d9') do
    its('ACSettingIndex') { should cmp == 0 }
  end
end

control 'cis-18.9.35.6.3' do
  title 'Ensure \'Require a password when a computer wakes (on battery)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.35.6.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Power\\PowerSettings\\0e796bdb-100d-47d6-a2d5-f7d2daa51f51') do
    its('DCSettingIndex') { should cmp == 1 }
  end
end

control 'cis-18.9.35.6.4' do
  title 'Ensure \'Require a password when a computer wakes (plugged in)\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.35.6.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Power\\PowerSettings\\0e796bdb-100d-47d6-a2d5-f7d2daa51f51') do
    its('ACSettingIndex') { should cmp == 1 }
  end
end

control 'cis-18.9.37.1' do
  title 'Ensure \'Configure Offer Remote Assistance\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.37.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fAllowUnsolicited') { should cmp == 0 }
  end
end

control 'cis-18.9.37.2' do
  title 'Ensure \'Configure Solicited Remote Assistance\' is set to \'Disabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.9.37.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.9.37.2): Ensure \'Configure Solicited Remote Assistance\' is set to \'Disabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Disabled: Computer Configuration\Policies\Administrative Templates\System\Remote Assistance\Configure Solicited Remote Assistance Note: This Group Policy path may not exist by default. It is provided by the Group Policy 
end

control 'cis-18.9.38.1' do
  title 'Ensure \'Enable RPC Endpoint Mapper Client Authentication\' is set to \'Enabled\' (MS only) (Automated)'
  impact 0.0
  tag cis_id: '18.9.38.1'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.9.38.1): Ensure \'Enable RPC Endpoint Mapper Client Authentication\' is set to \'Enabled\' (MS only) (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\System\Remote Procedure Call\Enable RPC Endpoint Mapper Client Authentication Note: This Group Policy path may not exist by default. It is provided by the
end

control 'cis-18.9.38.2' do
  title 'Ensure \'Restrict Unauthenticated RPC clients\' is set to \'Enabled: Authenticated\' (MS only) (Automated)'
  impact 0.0
  tag cis_id: '18.9.38.2'
  tag level: ['L2']
  tag scope: 'MS'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.9.38.2): Ensure \'Restrict Unauthenticated RPC clients\' is set to \'Enabled: Authenticated\' (MS only) (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Authenticated: Computer Configuration\Policies\Administrative Templates\System\Remote Procedure Call\Restrict Unauthenticated RPC clients Note: This Group Policy path may not exist by default. It is provided by 
end

control 'cis-18.9.41.1' do
  title 'Ensure \'Configure validation of ROCA-vulnerable WHfB keys during authentication\' is set to \'Enabled: Block\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '18.9.41.1'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\\SAM') do
    its('SamNGCKeyROCAValidation') { should cmp == 2 }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-18.9.49.5.1' do
  title 'Ensure \'Microsoft Support Diagnostic Tool: Turn on MSDT interactive communication with support provider\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.49.5.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\ScriptedDiagnosticsProvider\\Policy') do
    its('DisableQueryRemoteServer') { should cmp == 0 }
  end
end

control 'cis-18.9.49.11.1' do
  title 'Ensure \'Enable/Disable PerfTrack\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.49.11.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WDI\\{9c5a40da-b965-4fc3-8781-88dd50a6299d}') do
    its('ScenarioExecutionEnabled') { should cmp == 0 }
  end
end

control 'cis-18.9.51.1' do
  title 'Ensure \'Turn off the advertising ID\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.9.51.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AdvertisingInfo') do
    its('DisabledByGroupPolicy') { should cmp == 1 }
  end
end

control 'cis-18.9.53.1.1' do
  title 'Ensure \'Enable Windows NTP Client\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.9.53.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\W32Time\\TimeProviders\\NtpClient') do
    its('Enabled') { should cmp == 1 }
  end
end

control 'cis-18.9.53.1.2' do
  title 'Ensure \'Enable Windows NTP Server\' is set to \'Disabled\' (MS only) (Automated)'
  impact 0.5
  tag cis_id: '18.9.53.1.2'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\W32Time\\TimeProviders\\NtpServer') do
    its('Enabled') { should cmp == 0 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-18.10.4.1' do
  title 'Ensure \'Allow a Windows app to share application data between users\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.4.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CurrentVersion\\AppModel\\StateManager') do
    its('AllowSharedLocalAppData') { should cmp == 0 }
  end
end

control 'cis-18.10.6.1' do
  title 'Ensure \'Allow Microsoft accounts to be optional\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.6.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('MSAOptional') { should cmp == 1 }
  end
end

control 'cis-18.10.8.1' do
  title 'Ensure \'Disallow Autoplay for non-volume devices\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.8.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer') do
    its('NoAutoplayfornonVolume') { should cmp == 1 }
  end
end

control 'cis-18.10.8.2' do
  title 'Ensure \'Set the default behavior for AutoRun\' is set to \'Enabled: Do not execute any autorun commands\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.8.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('NoAutorun') { should cmp == 1 }
  end
end

control 'cis-18.10.8.3' do
  title 'Ensure \'Turn off Autoplay\' is set to \'Enabled: All drives\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.8.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('NoDriveTypeAutoRun') { should cmp == 255 }
  end
end

control 'cis-18.10.9.1.1' do
  title 'Ensure \'Configure enhanced anti-spoofing\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.9.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Biometrics\\FacialFeatures') do
    its('EnhancedAntiSpoofing') { should cmp == 1 }
  end
end

control 'cis-18.10.11.1' do
  title 'Ensure \'Allow Use of Camera\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.11.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Camera') do
    its('AllowCamera') { should cmp == 0 }
  end
end

control 'cis-18.10.13.1' do
  title 'Ensure \'Turn off cloud consumer account state content\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.13.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent') do
    its('DisableConsumerAccountStateContent') { should cmp == 1 }
  end
end

control 'cis-18.10.13.2' do
  title 'Ensure \'Turn off cloud optimized content\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.13.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent') do
    its('DisableCloudOptimizedContent') { should cmp == 1 }
  end
end

control 'cis-18.10.14.1' do
  title 'Ensure \'Require pin for pairing\' is set to \'Enabled: First Time\' OR \'Enabled: Always\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.14.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Connect') do
    its('RequirePinForPairing') { should be_in [1, 2] }
  end
end

control 'cis-18.10.15.1' do
  title 'Ensure \'Do not display the password reveal button\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.15.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CredUI') do
    its('DisablePasswordReveal') { should cmp == 1 }
  end
end

control 'cis-18.10.15.2' do
  title 'Ensure \'Enumerate administrator accounts on elevation\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.15.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\CredUI') do
    its('EnumerateAdministrators') { should cmp == 0 }
  end
end

control 'cis-18.10.16.1' do
  title 'Ensure \'Allow Diagnostic Data\' is set to \'Enabled: Diagnostic data off (not recommended)\' or \'Enabled: Send required diagnostic data\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.16.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection') do
    its('AllowTelemetry') { should be_in [0, 1] }
  end
end

control 'cis-18.10.16.2' do
  title 'Ensure \'Configure Authenticated Proxy usage for the Connected User Experience and Telemetry service\' is set to \'Enabled: Disable Authenticated Proxy usage\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.16.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection') do
    its('DisableEnterpriseAuthProxy') { should cmp == 1 }
  end
end

control 'cis-18.10.16.3' do
  title 'Ensure \'Do not show feedback notifications\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.16.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection') do
    its('DoNotShowFeedbackNotifications') { should cmp == 1 }
  end
end

control 'cis-18.10.16.4' do
  title 'Ensure \'Enable OneSettings Auditing\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.16.4'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection') do
    its('EnableOneSettingsAuditing') { should cmp == 1 }
  end
end

control 'cis-18.10.16.5' do
  title 'Ensure \'Limit Diagnostic Log Collection\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.16.5'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection') do
    its('LimitDiagnosticLogCollection') { should cmp == 1 }
  end
end

control 'cis-18.10.16.6' do
  title 'Ensure \'Limit Dump Collection\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.16.6'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection') do
    its('LimitDumpCollection') { should cmp == 1 }
  end
end

control 'cis-18.10.18.1' do
  title 'Ensure \'Enable App Installer\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.18.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableAppInstaller') { should cmp == 0 }
  end
end

control 'cis-18.10.18.2' do
  title 'Ensure \'Enable App Installer Experimental Features\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.18.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableExperimentalFeatures') { should cmp == 0 }
  end
end

control 'cis-18.10.18.3' do
  title 'Ensure \'Enable App Installer Hash Override\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.18.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableHashOverride') { should cmp == 0 }
  end
end

control 'cis-18.10.18.4' do
  title 'Ensure \'Enable App Installer Local Archive Malware Scan Override\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.18.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableLocalArchiveMalwareScanOverride') { should cmp == 0 }
  end
end

control 'cis-18.10.18.5' do
  title 'Ensure \'Enable App Installer ms-appinstaller protocol\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.18.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableMSAppInstallerProtocol') { should cmp == 0 }
  end
end

control 'cis-18.10.18.6' do
  title 'Ensure \'Enable App Installer Microsoft Store Source Certificate Validation Bypass\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.18.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableBypassCertificatePinningForMicrosoftStore') { should cmp == 0 }
  end
end

control 'cis-18.10.18.7' do
  title 'Ensure \'Enable Windows Package Manager command line interfaces\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.18.7'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\AppInstaller') do
    its('EnableWindowsPackageManagerCommandLineInterfaces') { should cmp == 0 }
  end
end

control 'cis-18.10.26.1.1' do
  title 'Ensure \'Application: Control Event Log behavior when the log file reaches its maximum size\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\Application') do
    its('Retention') { should cmp == 0 }
  end
end

control 'cis-18.10.26.1.2' do
  title 'Ensure \'Application: Specify the maximum log file size (KB)\' is set to \'Enabled: 32,768 or greater\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\Application') do
    its('MaxSize') { should cmp == 32768 }
  end
end

control 'cis-18.10.26.2.1' do
  title 'Ensure \'Security: Control Event Log behavior when the log file reaches its maximum size\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\Security') do
    its('Retention') { should cmp == 0 }
  end
end

control 'cis-18.10.26.2.2' do
  title 'Ensure \'Security: Specify the maximum log file size (KB)\' is set to \'Enabled: 196,608 or greater\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\Security') do
    its('MaxSize') { should cmp == 196608 }
  end
end

control 'cis-18.10.26.3.1' do
  title 'Ensure \'Setup: Control Event Log behavior when the log file reaches its maximum size\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.3.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\Setup') do
    its('Retention') { should cmp == 0 }
  end
end

control 'cis-18.10.26.3.2' do
  title 'Ensure \'Setup: Specify the maximum log file size (KB)\' is set to \'Enabled: 32,768 or greater\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.3.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\Setup') do
    its('MaxSize') { should cmp == 32768 }
  end
end

control 'cis-18.10.26.4.1' do
  title 'Ensure \'System: Control Event Log behavior when the log file reaches its maximum size\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.4.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\System') do
    its('Retention') { should cmp == 0 }
  end
end

control 'cis-18.10.26.4.2' do
  title 'Ensure \'System: Specify the maximum log file size (KB)\' is set to \'Enabled: 32,768 or greater\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.26.4.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\EventLog\\System') do
    its('MaxSize') { should cmp == 32768 }
  end
end

control 'cis-18.10.29.2' do
  title 'Ensure \'Do not apply the Mark of the Web tag to files copied from insecure sources\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.29.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer') do
    its('DisableMotWOnInsecurePathCopy') { should cmp == 0 }
  end
end

control 'cis-18.10.29.3' do
  title 'Ensure \'Turn off Data Execution Prevention for Explorer\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.29.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer') do
    its('NoDataExecutionPrevention') { should cmp == 0 }
  end
end

control 'cis-18.10.29.4' do
  title 'Ensure \'Turn off heap termination on corruption\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.29.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer') do
    its('NoHeapTerminationOnCorruption') { should cmp == 0 }
  end
end

control 'cis-18.10.29.5' do
  title 'Ensure \'Turn off shell protocol protected mode\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.29.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer') do
    its('PreXPSP2ShellProtocolBehavior') { should cmp == 0 }
  end
end

control 'cis-18.10.36.1' do
  title 'Ensure \'Turn off location\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.36.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors') do
    its('DisableLocation') { should cmp == 1 }
  end
end

control 'cis-18.10.40.1' do
  title 'Ensure \'Allow Message Service Cloud Sync\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.40.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Messaging') do
    its('AllowMessageSync') { should cmp == 0 }
  end
end

control 'cis-18.10.41.1' do
  title 'Ensure \'Block all consumer Microsoft account user authentication\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.41.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\MicrosoftAccount') do
    its('DisableUserAuth') { should cmp == 1 }
  end
end

control 'cis-18.10.42.4.1' do
  title 'Ensure \'Enable EDR in block mode\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.42.4.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.42.4.1): Ensure \'Enable EDR in block mode\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Microsoft Defender Antivirus\Features\Enable EDR in block mode Note: This Group Policy path is provided by the Group Policy template Wi
end

control 'cis-18.10.42.5.1' do
  title 'Ensure \'Configure local setting override for reporting to Microsoft MAPS\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.5.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\Spynet') do
    its('LocalSettingOverrideSpynetReporting') { should cmp == 0 }
  end
end

control 'cis-18.10.42.5.2' do
  title 'Ensure \'Join Microsoft MAPS\' is set to \'Enabled: Advanced\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.42.5.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.42.5.2): Ensure \'Join Microsoft MAPS\' is set to \'Enabled: Advanced\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Advanced: Computer Configuration\Policies\Administrative Templates\Windows Components\Microsoft Defender Antivirus\MAPS\Join Microsoft MAPS Note: This Group Policy path is provided by the Group Policy template W
end

control 'cis-18.10.42.6.1.1' do
  title 'Ensure \'Configure Attack Surface Reduction rules\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.6.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsGuard\\ASR') do
    its('ExploitGuard_ASR_Rules') { should cmp == 1 }
  end
end

control 'cis-18.10.42.6.1.2' do
  title 'Ensure \'Configure Attack Surface Reduction rules: Set the state for each ASR rule\' is configured (Automated)'
  impact 0.0
  tag cis_id: '18.10.42.6.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.42.6.1.2): Ensure \'Configure Attack Surface Reduction rules: Set the state for each ASR rule\' is configured (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path so that 26190899-1602-49e8-8b27-eb1d0a1ce869, 3b576869-a4ec-4529-8536- b80a7769e899, 56a863a9-875e-4185-98a7-b882c64b5ce5, 5beb7efe-fd9a-4556- 801d-275e5ffc04cc, 75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84, 7674ba52-37eb- 4a4f-a9a
end

control 'cis-18.10.42.6.3.1' do
  title 'Ensure \'Prevent users and apps from accessing dangerous websites\' is set to \'Enabled: Block\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.42.6.3.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.42.6.3.1): Ensure \'Prevent users and apps from accessing dangerous websites\' is set to \'Enabled: Block\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Block: Computer Configuration\Policies\Administrative Templates\Windows Components\Microsoft Defender Antivirus\Microsoft Defender Exploit Guard\Network Protection\Prevent users and apps from accessing dangerous
end

control 'cis-18.10.42.7.1' do
  title 'Ensure \'Enable file hash computation feature\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.7.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\MpEngine') do
    its('EnableFileHashComputation') { should cmp == 1 }
  end
end

control 'cis-18.10.42.8.1' do
  title 'Ensure \'Convert warn verdict to block\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.42.8.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\NIS') do
    its('EnableConvertWarnToBlock') { should cmp == 1 }
  end
end

control 'cis-18.10.42.10.1' do
  title 'Ensure \'Configure real-time protection and Security Intelligence Updates during OOBE\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.10.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsProtection') do
    its('OobeEnableRtpAndSigUpdate') { should cmp == 1 }
  end
end

control 'cis-18.10.42.10.2' do
  title 'Ensure \'Scan all downloaded files and attachments\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.10.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsProtection') do
    its('DisableIOAVProtection') { should cmp == 0 }
  end
end

control 'cis-18.10.42.10.3' do
  title 'Ensure \'Turn off real-time protection\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.10.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsProtection') do
    its('DisableRealtimeMonitoring') { should cmp == 0 }
  end
end

control 'cis-18.10.42.10.4' do
  title 'Ensure \'Turn on behavior monitoring\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.10.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsProtection') do
    its('DisableBehaviorMonitoring') { should cmp == 0 }
  end
end

control 'cis-18.10.42.10.5' do
  title 'Ensure \'Turn on script scanning\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.10.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsProtection') do
    its('DisableScriptScanning') { should cmp == 0 }
  end
end

control 'cis-18.10.42.12.1' do
  title 'Ensure \'Configure Watson events\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.42.12.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\Reporting') do
    its('DisableGenericRePorts') { should cmp == 1 }
  end
end

control 'cis-18.10.42.13.1' do
  title 'Ensure \'Scan excluded files and directories during quick scans\' is set to \'Enabled: 1\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.13.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\Scan') do
    its('QuickScanIncludeExclusions') { should cmp == 1 }
  end
end

control 'cis-18.10.42.13.2' do
  title 'Ensure \'Scan packed executables\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.13.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\Scan') do
    its('DisablePackedExeScanning') { should cmp == 0 }
  end
end

control 'cis-18.10.42.13.3' do
  title 'Ensure \'Scan removable drives\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.13.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\Scan') do
    its('DisableRemovableDriveScanning') { should cmp == 0 }
  end
end

control 'cis-18.10.42.13.4' do
  title 'Ensure \'Trigger a quick scan after X days without any scans\' is set to \'Enabled: 7\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.13.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender\\Scan') do
    its('DaysUntilAggressiveCatchupQuickScan') { should cmp == 7 }
  end
end

control 'cis-18.10.42.13.5' do
  title 'Ensure \'Turn on e-mail scanning\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.42.13.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.42.13.5): Ensure \'Turn on e-mail scanning\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Microsoft Defender Antivirus\Scan\Turn on e-mail scanning Note: This Group Policy path may not exist by default. It is provided by the 
end

control 'cis-18.10.42.16' do
  title 'Ensure \'Configure detection for potentially unwanted applications\' is set to \'Enabled: Block\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.42.16'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.42.16): Ensure \'Configure detection for potentially unwanted applications\' is set to \'Enabled: Block\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Block: Computer Configuration\Policies\Administrative Templates\Windows Components\Microsoft Defender Antivirus\Configure detection for potentially unwanted applications Note: This Group Policy path is provided 
end

control 'cis-18.10.42.17' do
  title 'Ensure \'Control whether exclusions are visible to local users\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.42.17'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsDefender') do
    its('HideExclusionsFromLocalUsers') { should cmp == 1 }
  end
end

control 'cis-18.10.56.1' do
  title 'Ensure \'Turn off Push To Install service\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.56.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\PushToInstall') do
    its('DisablePushToInstall') { should cmp == 1 }
  end
end

control 'cis-18.10.57.2.2' do
  title 'Ensure \'Do not allow passwords to be saved\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('DisablePasswordSaving') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.2.1' do
  title 'Ensure \'Restrict Remote Desktop Services users to a single Remote Desktop Services session\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.2.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fSingleSessionPerUser') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.3.1' do
  title 'Ensure \'Allow UI Automation redirection\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.3.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('EnableUiaRedirection') { should cmp == 0 }
  end
end

control 'cis-18.10.57.3.3.2' do
  title 'Ensure \'Do not allow COM port redirection\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.57.3.3.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.57.3.3.2): Ensure \'Do not allow COM port redirection\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Remote Desktop Services\Remote Desktop Session Host\Device and Resource Redirection\Do not allow COM port redirection Note: This Group 
end

control 'cis-18.10.57.3.3.3' do
  title 'Ensure \'Do not allow drive redirection\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.57.3.3.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.57.3.3.3): Ensure \'Do not allow drive redirection\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Remote Desktop Services\Remote Desktop Session Host\Device and Resource Redirection\Do not allow drive redirection Note: This Group Pol
end

control 'cis-18.10.57.3.3.4' do
  title 'Ensure \'Do not allow location redirection\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.3.4'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fDisableLocationRedir') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.3.5' do
  title 'Ensure \'Do not allow LPT port redirection\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.57.3.3.5'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.57.3.3.5): Ensure \'Do not allow LPT port redirection\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Remote Desktop Services\Remote Desktop Session Host\Device and Resource Redirection\Do not allow LPT port redirection Note: This Group 
end

control 'cis-18.10.57.3.3.6' do
  title 'Ensure \'Do not allow supported Plug and Play device redirection\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.3.6'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fDisablePNPRedir') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.3.7' do
  title 'Ensure \'Do not allow WebAuthn redirection\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.3.7'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fDisableWebAuthn') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.9.1' do
  title 'Ensure \'Always prompt for password upon connection\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.3.9.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fPromptForPassword') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.9.2' do
  title 'Ensure \'Require secure RPC communication\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.3.9.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('fEncryptRPCTraffic') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.9.3' do
  title 'Ensure \'Require use of specific security layer for remote (RDP) connections\' is set to \'Enabled: SSL\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.57.3.9.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.57.3.9.3): Ensure \'Require use of specific security layer for remote (RDP) connections\' is set to \'Enabled: SSL\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: SSL: Computer Configuration\Policies\Administrative Templates\Windows Components\Remote Desktop Services\Remote Desktop Session Host\Security\Require use of specific security layer for remote (RDP) connections N
end

control 'cis-18.10.57.3.9.4' do
  title 'Ensure \'Require user authentication for remote connections by using Network Level Authentication\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.3.9.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('UserAuthentication') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.9.5' do
  title 'Ensure \'Set client connection encryption level\' is set to \'Enabled: High Level\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.3.9.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('MinEncryptionLevel') { should cmp == 3 }
  end
end

control 'cis-18.10.57.3.10.1' do
  title 'Ensure \'Set time limit for active but idle Remote Desktop Services sessions\' is set to \'Enabled: 15 minutes or less, but not Never (0)\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.10.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('MaxIdleTime') { should cmp >= 1 }
    its('MaxIdleTime') { should cmp <= 900000 }
  end
end

control 'cis-18.10.57.3.10.2' do
  title 'Ensure \'Set time limit for disconnected sessions\' is set to \'Enabled: 1 minute\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.57.3.10.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('MaxDisconnectionTime') { should cmp == 60000 }
  end
end

control 'cis-18.10.57.3.11.1' do
  title 'Ensure \'Do not delete temp folders upon exit\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.3.11.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('DeleteTempDirsOnExit') { should cmp == 1 }
  end
end

control 'cis-18.10.57.3.11.2' do
  title 'Ensure \'Do not use temporary folders per session\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.57.3.11.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsServices') do
    its('PerSessionTempDir') { should cmp == 1 }
  end
end

control 'cis-18.10.58.1' do
  title 'Ensure \'Prevent downloading of enclosures\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.58.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\InternetExplorer\\Feeds') do
    its('DisableEnclosureDownload') { should cmp == 1 }
  end
end

control 'cis-18.10.58.2' do
  title 'Ensure \'Turn on Basic feed authentication over HTTP\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.58.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\InternetExplorer\\Feeds') do
    # REVIEW: organization-specific value -- benchmark prescribes: 0:
    it { should have_property 'AllowBasicAuthInClear' }
  end
end

control 'cis-18.10.59.2' do
  title 'Ensure \'Allow Cloud Search\' is set to \'Enabled: Disable Cloud Search\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.59.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.59.2): Ensure \'Allow Cloud Search\' is set to \'Enabled: Disable Cloud Search\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Disable Cloud Search: Computer Configuration\Policies\Administrative Templates\Windows Components\Search\Allow Cloud Search Note: This Group Policy path may not exist by default. It is provided by the Group Poli
end

control 'cis-18.10.59.3' do
  title 'Ensure \'Allow indexing of encrypted files\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.59.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsSearch') do
    its('AllowIndexingEncryptedStoresOrItems') { should cmp == 0 }
  end
end

control 'cis-18.10.59.4' do
  title 'Ensure \'Allow search highlights\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.59.4'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsSearch') do
    its('EnableDynamicContentInWSB') { should cmp == 0 }
  end
end

control 'cis-18.10.63.1' do
  title 'Ensure \'Turn off KMS Client Online AVS Validation\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.63.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.63.1): Ensure \'Turn off KMS Client Online AVS Validation\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Software Protection Platform\Turn off KMS Client Online AVS Validation Note: This Group Policy path may not exist by default. It is pro
end

control 'cis-18.10.77.2.1' do
  title 'Ensure \'Configure Windows Defender SmartScreen\' is set to \'Enabled: Warn and prevent bypass\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.77.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\System') do
    # REVIEW: organization-specific value -- benchmark prescribes: 1 (EnableSmartScreen) and REG_SZ value of Block
    it { should have_property 'EnableSmartScreen' }
  end
end

control 'cis-18.10.81.1' do
  title 'Ensure \'Allow suggested apps in Windows Ink Workspace\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.81.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsInkWorkspace') do
    its('AllowSuggestedAppsInWindowsInkWorkspace') { should cmp == 0 }
  end
end

control 'cis-18.10.81.2' do
  title 'Ensure \'Allow Windows Ink Workspace\' is set to \'Enabled: On, but disallow access above lock\' OR \'Enabled: Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.81.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsInkWorkspace') do
    its('AllowWindowsInkWorkspace') { should be_in [0, 1] }
  end
end

control 'cis-18.10.82.1' do
  title 'Ensure \'Allow user control over installs\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.82.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer') do
    its('EnableUserControl') { should cmp == 0 }
  end
end

control 'cis-18.10.82.2' do
  title 'Ensure \'Always install with elevated privileges\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.82.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer') do
    its('AlwaysInstallElevated') { should cmp == 0 }
  end
end

control 'cis-18.10.82.3' do
  title 'Ensure \'Prevent Internet Explorer security prompt for Windows Installer scripts\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.82.3'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer') do
    its('SafeForScripting') { should cmp == 0 }
  end
end

control 'cis-18.10.83.1' do
  title 'Ensure \'Configure the transmission of the user\'s password in the content of MPR notifications sent by winlogon.\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.83.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('EnableMPR') { should cmp == 0 }
  end
end

control 'cis-18.10.83.2' do
  title 'Ensure \'Sign-in and lock last interactive user automatically after a restart\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.83.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System') do
    its('DisableAutomaticRestartSignOn') { should cmp == 1 }
  end
end

control 'cis-18.10.88.1' do
  title 'Ensure \'Turn on PowerShell Script Block Logging\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.88.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptBlockLogging') do
    its('EnableScriptBlockLogging') { should cmp == 1 }
  end
end

control 'cis-18.10.88.2' do
  title 'Ensure \'Turn on PowerShell Transcription\' is set to \'Enabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.88.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\Transcription') do
    its('EnableTranscripting') { should cmp == 1 }
  end
end

control 'cis-18.10.90.1.1' do
  title 'Ensure \'Allow Basic authentication\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.90.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Client') do
    its('AllowBasic') { should cmp == 0 }
  end
end

control 'cis-18.10.90.1.2' do
  title 'Ensure \'Allow unencrypted traffic\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.90.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Client') do
    its('AllowUnencryptedTraffic') { should cmp == 0 }
  end
end

control 'cis-18.10.90.1.3' do
  title 'Ensure \'Disallow Digest authentication\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.90.1.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Client') do
    its('AllowDigest') { should cmp == 0 }
  end
end

control 'cis-18.10.90.2.1' do
  title 'Ensure \'Allow Basic authentication\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.90.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Service') do
    its('AllowBasic') { should cmp == 0 }
  end
end

control 'cis-18.10.90.2.2' do
  title 'Ensure \'Allow remote server management through WinRM\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.90.2.2'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Service') do
    its('AllowAutoConfig') { should cmp == 0 }
  end
end

control 'cis-18.10.90.2.3' do
  title 'Ensure \'Allow unencrypted traffic\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.90.2.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Service') do
    its('AllowUnencryptedTraffic') { should cmp == 0 }
  end
end

control 'cis-18.10.90.2.4' do
  title 'Ensure \'Disallow WinRM from storing RunAs credentials\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.90.2.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Service') do
    its('DisableRunAs') { should cmp == 1 }
  end
end

control 'cis-18.10.91.1' do
  title 'Ensure \'Allow Remote Shell Access\' is set to \'Disabled\' (Automated)'
  impact 0.7
  tag cis_id: '18.10.91.1'
  tag level: ['L2']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WinRM\\Service\\WinRS') do
    its('AllowRemoteShellAccess') { should cmp == 0 }
  end
end

control 'cis-18.10.93.2.1' do
  title 'Ensure \'Prevent users from modifying settings\' is set to \'Enabled\' (Automated)'
  impact 0.0
  tag cis_id: '18.10.93.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'manual'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (18.10.93.2.1): Ensure \'Prevent users from modifying settings\' is set to \'Enabled\' (Automated)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Administrative Templates\Windows Components\Windows Security\App and browser protection\Prevent users from modifying settings Note: This Group Policy path may not exist by default
end

control 'cis-18.10.94.1.1' do
  title 'Ensure \'No auto-restart with logged on users for scheduled automatic updates installations\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.94.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU') do
    its('NoAutoRebootWithLoggedOnUsers') { should cmp == 0 }
  end
end

control 'cis-18.10.94.2.1' do
  title 'Ensure \'Configure Automatic Updates\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.94.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU') do
    its('NoAutoUpdate') { should cmp == 0 }
  end
end

control 'cis-18.10.94.2.2' do
  title 'Ensure \'Configure Automatic Updates: Scheduled install day\' is set to \'0 - Every day\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.94.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU') do
    its('ScheduledInstallDay') { should cmp == 0 }
  end
end

control 'cis-18.10.94.4.1' do
  title 'Ensure \'Manage preview builds\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.94.4.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate') do
    its('ManagePreviewBuildsPolicyValue') { should cmp == 1 }
  end
end

control 'cis-18.10.94.4.2' do
  title 'Ensure \'Select when Quality Updates are received\' is set to \'Enabled: 0 days\' (Automated)'
  impact 0.5
  tag cis_id: '18.10.94.4.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate') do
    # REVIEW: organization-specific value -- benchmark prescribes: 1 (DeferQualityUpdates) and 0
    it { should have_property 'DeferQualityUpdates' }
  end
end

control 'cis-18.11.1' do
  title 'Ensure \'Disable HTTP proxy features: Disable WPAD\' is set to \'Enabled: Checked\' (Automated)'
  impact 0.5
  tag cis_id: '18.11.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\InternetSettings\\WinHttp') do
    its('DisableWpad') { should cmp == 1 }
  end
end

control 'cis-18.11.2' do
  title 'Ensure \'Disable HTTP proxy features: Disable proxy authentication\' is set to \'Enabled: Disable authentication over loopback interfaces\' or higher (Automated)'
  impact 0.5
  tag cis_id: '18.11.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\InternetSettings') do
    its('DisableProxyAuthenticationSchemes') { should be_in [256, 287] }
  end
end
