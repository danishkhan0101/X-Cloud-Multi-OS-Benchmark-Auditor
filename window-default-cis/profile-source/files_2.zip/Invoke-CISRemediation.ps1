<#
.SYNOPSIS
    Applies CIS Microsoft Windows Server 2022 Benchmark v5.0.0 remediation.

.DESCRIPTION
    Orchestrator for the per-section remediation scripts under .\sections.
    Defines the shared helper functions (registry / auditpol wrappers + logging),
    takes a pre-change backup, then dot-sources and runs the selected sections.

    Every change-making helper supports -WhatIf, so running this script with
    -WhatIf performs a full dry run and writes nothing.

.PARAMETER ServerRole
    member_server (default) or domain_controller. Selects the correct value for
    the handful of recommendations whose prescribed setting differs by role.

.PARAMETER Sections
    One or more section numbers to run: 1, 2, 9, 17, 18, 19. Default = all.

.PARAMETER SkipBackup
    Skip the secedit / auditpol / registry export taken before changes.

.PARAMETER BackupDir
    Directory for the pre-change backup. Default under %ProgramData%.

.PARAMETER LogDir
    Directory for the transcript log. Default under %ProgramData%.

.EXAMPLE
    # Full dry run - shows every change, modifies nothing
    .\Invoke-CISRemediation.ps1 -ServerRole member_server -WhatIf

.EXAMPLE
    # Apply only firewall + audit policy on a domain controller
    .\Invoke-CISRemediation.ps1 -ServerRole domain_controller -Sections 9,17

.NOTES
    Auto-generated companion to the CINC Auditor / InSpec profile. Test on a
    non-production host first. Review organization-specific (REVIEW) settings,
    which are intentionally NOT changed automatically.
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [ValidateSet("member_server", "domain_controller")]
    [string]$ServerRole = "member_server",

    [ValidateSet("1", "2", "9", "17", "18", "19")]
    [string[]]$Sections,

    [switch]$SkipBackup,

    [string]$BackupDir = (Join-Path $env:ProgramData ("CIS-WS2022-Remediation\backup-{0}" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))),

    [string]$LogDir = (Join-Path $env:ProgramData "CIS-WS2022-Remediation\logs")
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Shared helper functions (used by every section script)
# ---------------------------------------------------------------------------
function Write-CISLog {
    param([string]$Message)
    Write-Host ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message)
}

function Write-CISWarn {
    param([string]$Message)
    Write-Warning ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message)
}

function Set-CISRegValue {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)]
        [ValidateSet("DWord", "QWord", "String", "ExpandString", "MultiString", "Binary")]
        [string]$Type,
        [Parameter(Mandatory)]$Value
    )
    if ($PSCmdlet.ShouldProcess(("{0}\{1}" -f $Path, $Name), ("Set {0} = {1}" -f $Type, $Value))) {
        try {
            if (-not (Test-Path -Path $Path)) {
                # -Force creates any missing parent keys in the registry provider.
                New-Item -Path $Path -Force | Out-Null
            }
            New-ItemProperty -Path $Path -Name $Name -PropertyType $Type -Value $Value -Force | Out-Null
        }
        catch {
            Write-CISWarn ("Failed to set {0}\{1}: {2}" -f $Path, $Name, $_.Exception.Message)
        }
    }
}

function Remove-CISRegValue {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name
    )
    if (Test-Path -Path $Path) {
        if ($PSCmdlet.ShouldProcess(("{0}\{1}" -f $Path, $Name), "Remove value")) {
            Remove-ItemProperty -Path $Path -Name $Name -Force -ErrorAction SilentlyContinue
        }
    }
}

function Set-CISAudit {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$Subcategory,
        [ValidateSet("enable", "disable")][string]$Success = "disable",
        [ValidateSet("enable", "disable")][string]$Failure = "disable"
    )
    if ($PSCmdlet.ShouldProcess(("Audit '{0}'" -f $Subcategory), ("Success={0} Failure={1}" -f $Success, $Failure))) {
        & auditpol /set /subcategory:"$Subcategory" /success:$Success /failure:$Failure | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Write-CISWarn ("auditpol failed for subcategory '{0}' (exit {1})" -f $Subcategory, $LASTEXITCODE)
        }
    }
}

function Backup-CISState {
    param([Parameter(Mandatory)][string]$Dir)
    New-Item -ItemType Directory -Path $Dir -Force | Out-Null
    Write-CISLog "Taking pre-change backup..."
    & secedit /export /cfg (Join-Path $Dir 'security-policy-before.inf') /quiet | Out-Null
    & auditpol /backup /file:(Join-Path $Dir 'audit-policy-before.csv') | Out-Null
    foreach ($hive in 'HKLM\SOFTWARE', 'HKLM\SYSTEM', 'HKU\.DEFAULT') {
        $safe = ($hive -replace '[\\\.]', '_')
        & reg export $hive (Join-Path $Dir ("{0}-before.reg" -f $safe)) /y 2>$null | Out-Null
    }
    Write-CISLog ("Backup written to {0}" -f $Dir)
}

# ---------------------------------------------------------------------------
# Pre-flight
# ---------------------------------------------------------------------------
$identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Invoke-CISRemediation must be run from an elevated (Administrator) PowerShell session."
}

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sectionDir = Join-Path $here 'sections'
if (-not (Test-Path $sectionDir)) {
    throw ("Section scripts not found at {0}" -f $sectionDir)
}

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
$logFile = Join-Path $LogDir ("remediation-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -Path $logFile -Append | Out-Null

try {
    Write-CISLog "=== CIS Windows Server 2022 v5.0.0 remediation ==="
    Write-CISLog ("Server role : {0}" -f $ServerRole)
    Write-CISLog ("WhatIf mode : {0}" -f [bool]$WhatIfPreference)

    # Load all section scripts (defines the Set-CIS* functions).
    Get-ChildItem -Path $sectionDir -Filter '*.ps1' | Sort-Object Name | ForEach-Object {
        . $_.FullName
    }

    if (-not $SkipBackup -and -not $WhatIfPreference) {
        Backup-CISState -Dir $BackupDir
    }
    else {
        Write-CISLog "Skipping backup (either -SkipBackup or -WhatIf)."
    }

    # section number -> remediation action
    $actions = [ordered]@{
        '1'  = { Set-CISAccountPolicies -BackupDir $BackupDir }
        '2'  = {
                   Set-CISUserRights      -ServerRole $ServerRole -BackupDir $BackupDir
                   Set-CISSecurityOptions -ServerRole $ServerRole -BackupDir $BackupDir
               }
        '9'  = { Set-CISWindowsFirewall        -ServerRole $ServerRole -BackupDir $BackupDir }
        '17' = { Set-CISAuditPolicy            -ServerRole $ServerRole -BackupDir $BackupDir }
        '18' = { Set-CISAdminTemplatesComputer -ServerRole $ServerRole -BackupDir $BackupDir }
        '19' = { Set-CISAdminTemplatesUser     -ServerRole $ServerRole -BackupDir $BackupDir }
    }

    $run = if ($Sections) { $Sections } else { $actions.Keys }
    foreach ($s in $run) {
        if ($actions.Contains([string]$s)) {
            & $actions[[string]$s]
        }
        else {
            Write-CISWarn ("Unknown section '{0}' - skipped." -f $s)
        }
    }

    Write-CISLog "=== Remediation complete ==="
    Write-CISLog "Re-run the InSpec/CINC Auditor profile to confirm the resulting state."
    if (-not $WhatIfPreference) {
        Write-CISLog "Some settings (audit policy, user rights, per-user keys) take effect at next logon / policy refresh; a reboot is recommended."
    }
}
finally {
    Stop-Transcript | Out-Null
}
