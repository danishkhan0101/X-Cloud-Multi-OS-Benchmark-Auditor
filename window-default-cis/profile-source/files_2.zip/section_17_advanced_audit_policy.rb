# encoding: UTF-8
# CIS Microsoft Windows Server 2022 Benchmark v5.0.0
# Section 17 - Advanced Audit Policy Configuration
# Auto-generated; verify organization-specific (REVIEW) controls.

control 'cis-17.1.1' do
  title 'Ensure \'Audit Credential Validation\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Credential Validation') { should eq 'Success and Failure' }
  end
end

control 'cis-17.1.2' do
  title 'Ensure \'Audit Kerberos Authentication Service\' is set to \'Success and Failure\' (DC Only) (Automated)'
  impact 0.5
  tag cis_id: '17.1.2'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Kerberos Authentication Service') { should eq 'Success and Failure' }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.1.3' do
  title 'Ensure \'Audit Kerberos Service Ticket Operations\' is set to \'Success and Failure\' (DC Only) (Automated)'
  impact 0.5
  tag cis_id: '17.1.3'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Kerberos Service Ticket Operations') { should eq 'Success and Failure' }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.2.1' do
  title 'Ensure \'Audit Application Group Management\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Application Group Management') { should eq 'Success and Failure' }
  end
end

control 'cis-17.2.2' do
  title 'Ensure \'Audit Computer Account Management\' is set to include \'Success\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '17.2.2'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Computer Account Management') { should match /Success/ }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.2.3' do
  title 'Ensure \'Audit Distribution Group Management\' is set to include \'Success\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '17.2.3'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Distribution Group Management') { should match /Success/ }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.2.4' do
  title 'Ensure \'Audit Other Account Management Events\' is set to include \'Success\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '17.2.4'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Other Account Management Events') { should match /Success/ }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.2.5' do
  title 'Ensure \'Audit Security Group Management\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.2.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Security Group Management') { should match /Success/ }
  end
end

control 'cis-17.2.6' do
  title 'Ensure \'Audit User Account Management\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.2.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('User Account Management') { should eq 'Success and Failure' }
  end
end

control 'cis-17.3.1' do
  title 'Ensure \'Audit PNP Activity\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.3.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('PNP Activity') { should match /Success/ }
  end
end

control 'cis-17.3.2' do
  title 'Ensure \'Audit Process Creation\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.3.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Process Creation') { should match /Success/ }
  end
end

control 'cis-17.4.1' do
  title 'Ensure \'Audit Directory Service Access\' is set to include \'Failure\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '17.4.1'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Directory Service Access') { should match /Failure/ }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.4.2' do
  title 'Ensure \'Audit Directory Service Changes\' is set to include \'Success\' (DC only) (Automated)'
  impact 0.5
  tag cis_id: '17.4.2'
  tag level: ['L1']
  tag scope: 'DC'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Directory Service Changes') { should match /Success/ }
  end
  only_if('applies to Domain Controllers') { input('server_role') == 'domain_controller' }
end

control 'cis-17.5.1' do
  title 'Ensure \'Audit Account Lockout\' is set to include \'Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.5.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Account Lockout') { should match /Failure/ }
  end
end

control 'cis-17.5.2' do
  title 'Ensure \'Audit Group Membership\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.5.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Group Membership') { should match /Success/ }
  end
end

control 'cis-17.5.3' do
  title 'Ensure \'Audit Logoff\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.5.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Logoff') { should match /Success/ }
  end
end

control 'cis-17.5.4' do
  title 'Ensure \'Audit Logon\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.5.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Logon') { should eq 'Success and Failure' }
  end
end

control 'cis-17.5.5' do
  title 'Ensure \'Audit Other Logon/Logoff Events\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.5.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Other Logon/Logoff Events') { should eq 'Success and Failure' }
  end
end

control 'cis-17.5.6' do
  title 'Ensure \'Audit Special Logon\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.5.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Special Logon') { should match /Success/ }
  end
end

control 'cis-17.6.1' do
  title 'Ensure \'Audit Detailed File Share\' is set to include \'Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.6.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Detailed File Share') { should match /Failure/ }
  end
end

control 'cis-17.6.2' do
  title 'Ensure \'Audit File Share\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.6.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('File Share') { should eq 'Success and Failure' }
  end
end

control 'cis-17.6.3' do
  title 'Ensure \'Audit Other Object Access Events\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.6.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Other Object Access Events') { should eq 'Success and Failure' }
  end
end

control 'cis-17.6.4' do
  title 'Ensure \'Audit Removable Storage\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.6.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Removable Storage') { should eq 'Success and Failure' }
  end
end

control 'cis-17.7.1' do
  title 'Ensure \'Audit Audit Policy Change\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.7.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Audit Policy Change') { should match /Success/ }
  end
end

control 'cis-17.7.2' do
  title 'Ensure \'Audit Authentication Policy Change\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.7.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Authentication Policy Change') { should match /Success/ }
  end
end

control 'cis-17.7.3' do
  title 'Ensure \'Audit Authorization Policy Change\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.7.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Authorization Policy Change') { should match /Success/ }
  end
end

control 'cis-17.7.4' do
  title 'Ensure \'Audit MPSSVC Rule-Level Policy Change\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.7.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('MPSSVC Rule-Level Policy Change') { should eq 'Success and Failure' }
  end
end

control 'cis-17.7.5' do
  title 'Ensure \'Audit Other Policy Change Events\' is set to include \'Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.7.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Other Policy Change Events') { should match /Failure/ }
  end
end

control 'cis-17.8.1' do
  title 'Ensure \'Audit Sensitive Privilege Use\' is set to \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.8.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Sensitive Privilege Use') { should eq 'Success' }
  end
end

control 'cis-17.9.1' do
  title 'Ensure \'Audit IPsec Driver\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.9.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('IPsec Driver') { should eq 'Success and Failure' }
  end
end

control 'cis-17.9.2' do
  title 'Ensure \'Audit Other System Events\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.9.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Other System Events') { should eq 'Success and Failure' }
  end
end

control 'cis-17.9.3' do
  title 'Ensure \'Audit Security State Change\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.9.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Security State Change') { should match /Success/ }
  end
end

control 'cis-17.9.4' do
  title 'Ensure \'Audit Security System Extension\' is set to include \'Success\' (Automated)'
  impact 0.5
  tag cis_id: '17.9.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('Security System Extension') { should match /Success/ }
  end
end

control 'cis-17.9.5' do
  title 'Ensure \'Audit System Integrity\' is set to \'Success and Failure\' (Automated)'
  impact 0.5
  tag cis_id: '17.9.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'audit_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe audit_policy do
    its('System Integrity') { should eq 'Success and Failure' }
  end
end
