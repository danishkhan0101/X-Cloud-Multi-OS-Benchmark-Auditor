# encoding: UTF-8
# CIS Microsoft Windows Server 2022 Benchmark v5.0.0
# Section 1 - Account Policies
# Auto-generated; verify organization-specific (REVIEW) controls.

control 'cis-1.1.1' do
  title 'Ensure \'Enforce password history\' is set to \'24 or more password(s)\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'password_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('PasswordHistorySize') { should cmp >= 24 }
  end
end

control 'cis-1.1.2' do
  title 'Ensure \'Maximum password age\' is set to \'365 or fewer days, but not 0\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'password_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('MaximumPasswordAge') { should cmp <= 365 }
    its('MaximumPasswordAge') { should cmp > 0 }
  end
end

control 'cis-1.1.3' do
  title 'Ensure \'Minimum password age\' is set to \'1 or more day(s)\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'password_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('MinimumPasswordAge') { should cmp >= 1 }
  end
end

control 'cis-1.1.4' do
  title 'Ensure \'Minimum password length\' is set to \'14 or more character(s)\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'password_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('MinimumPasswordLength') { should cmp >= 14 }
  end
end

control 'cis-1.1.5' do
  title 'Ensure \'Password must meet complexity requirements\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'password_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('PasswordComplexity') { should cmp == 1 }
  end
end

control 'cis-1.1.6' do
  title 'Ensure \'Relax minimum password length limits\' is set to \'Enabled\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.6'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\System\\CurrentControlSet\\Control\\SAM') do
    its('RelaxMinimumPasswordLengthLimits') { should cmp == 1 }
  end
  only_if('applies to Member Servers') { input('server_role') == 'member_server' }
end

control 'cis-1.1.7' do
  title 'Ensure \'Store passwords using reversible encryption\' is set to \'Disabled\' (Automated)'
  impact 0.5
  tag cis_id: '1.1.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'password_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('ClearTextPassword') { should cmp == 0 }
  end
end

control 'cis-1.2.1' do
  title 'Ensure \'Account lockout duration\' is set to \'15 or more minute(s)\' (Automated)'
  impact 0.5
  tag cis_id: '1.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'lockout_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('LockoutDuration') { should cmp >= 15 }
  end
end

control 'cis-1.2.2' do
  title 'Ensure \'Account lockout threshold\' is set to \'5 or fewer invalid logon attempt(s), but not 0\' (Automated)'
  impact 0.5
  tag cis_id: '1.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'lockout_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('LockoutBadCount') { should cmp >= 1 }
    its('LockoutBadCount') { should cmp <= 5 }
  end
end

control 'cis-1.2.3' do
  title 'Ensure \'Allow Administrator account lockout\' is set to \'Enabled\' (MS only) (Manual)'
  impact 0.5
  tag cis_id: '1.2.3'
  tag level: ['L1']
  tag scope: 'MS'
  tag mechanism: 'lockout_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe 'Manual review required' do
    skip 'Manual check (1.2.3): Ensure \'Allow Administrator account lockout\' is set to \'Enabled\' (MS only) (Manual)'
  end
  # Remediation guidance: To establish the recommended configuration via GP, set the following UI path to Enabled: Computer Configuration\Policies\Windows Settings\Security Settings\Account Policies\Account Lockout Policies\Allow Administrator account lockout
end

control 'cis-1.2.4' do
  title 'Ensure \'Reset account lockout counter after\' is set to \'15 or more minute(s)\' (Automated)'
  impact 0.5
  tag cis_id: '1.2.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'lockout_policy'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe security_policy do
    its('ResetLockoutCount') { should cmp >= 15 }
  end
end
