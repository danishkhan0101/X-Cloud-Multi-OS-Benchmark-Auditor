# CIS Microsoft Windows Server 2022 Benchmark v5.0.0 — CINC Auditor / InSpec profile + remediation

A compliance profile that **scans** a Windows Server 2022 host against the CIS
Benchmark v5.0.0 (02-20-2026), plus matching **PowerShell remediation** that brings
a host into the prescribed state.

The profile runs under [CINC Auditor](https://cinc.sh/) (`cinc-auditor`) or
Chef InSpec — the control DSL is identical.

```
cis-win2022/
├── inspec.yml            # profile metadata + inputs
├── inputs.yml            # example input file (server_role, profile_level)
├── COVERAGE.md           # generated coverage breakdown
├── controls/             # the scanning controls (Ruby / InSpec DSL)
│   ├── section_01_account_policies.rb
│   ├── section_02_local_policies.rb        (User Rights + Security Options)
│   ├── section_05_system_services.rb
│   ├── section_09_windows_firewall.rb
│   ├── section_17_advanced_audit_policy.rb
│   ├── section_18_admin_templates_computer.rb
│   └── section_19_admin_templates_user.rb
└── remediation/
    ├── Invoke-CISRemediation.ps1           # orchestrator (run this)
    └── sections/                           # one script per benchmark section
```

---

## 1. Scanning

### Requirements
- CINC Auditor (`cinc-auditor`) or Chef InSpec on the machine you run *from*.
- The target is Windows Server 2022. You can scan the local host or a remote host over WinRM.
- The audit account needs local admin on the target (registry, security policy, and audit policy reads).

### Run against the local host
```powershell
cinc-auditor exec . --input-file inputs.yml
```

### Run against a remote host (WinRM)
```bash
cinc-auditor exec . -t winrm://HOST --user 'DOMAIN\auditor' --password '***' \
  --input-file inputs.yml
```

### Pick the target role
Several recommendations differ between a domain controller and a member server.
Set `server_role` so the right ones are evaluated and the inapplicable ones are skipped:

```yaml
# inputs.yml
server_role: member_server     # or: domain_controller
profile_level: 1               # informational; L2 controls are tagged level: ['L2']
```

You can also pass it inline: `--input server_role=domain_controller`.

### Useful output formats
```bash
# human-readable progress
cinc-auditor exec . --input-file inputs.yml --reporter cli

# machine-readable for dashboards / CI
cinc-auditor exec . --input-file inputs.yml --reporter json:results.json
```

### Filtering by level or section
Every control is tagged, so you can scope a run:
```bash
# Level 1 only
cinc-auditor exec . --input-file inputs.yml --controls /cis-/ \
  --reporter cli  # then filter on tag level in your reporting, or:
cinc-auditor exec . --input-file inputs.yml -t winrm://HOST \
  --filter-empty-profiles
```
Each control carries: `tag cis_id`, `tag level` (`['L1']` / `['L2']`),
`tag scope` (`ALL` / `DC` / `MS`), and `tag mechanism`.

---

## 2. Remediation

> **Run a dry run first, and test on a non-production host before applying.**

The remediation mirrors the profile section-for-section. The orchestrator defines the
shared helpers, takes a pre-change backup, then runs the section scripts you select.

### Dry run (changes nothing)
```powershell
.\remediation\Invoke-CISRemediation.ps1 -ServerRole member_server -WhatIf
```
Every change-making step honours `-WhatIf`, so this prints exactly what *would* change.

### Apply everything
```powershell
# from an elevated PowerShell session
.\remediation\Invoke-CISRemediation.ps1 -ServerRole member_server
```

### Apply selected sections only
```powershell
.\remediation\Invoke-CISRemediation.ps1 -ServerRole domain_controller -Sections 9,17
```
Valid sections: `1` (account policies), `2` (user rights + security options),
`9` (firewall), `17` (audit policy), `18` (admin templates – computer),
`19` (admin templates – user).

### What it does for you
- **Admin check** — refuses to run unless elevated.
- **Backup** (unless `-SkipBackup` or `-WhatIf`): `secedit /export`, `auditpol /backup`,
  and `reg export` of `HKLM\SOFTWARE`, `HKLM\SYSTEM`, `HKU\.DEFAULT` into a timestamped
  folder under `%ProgramData%\CIS-WS2022-Remediation\backup-*`.
- **Transcript** of the whole run under `%ProgramData%\CIS-WS2022-Remediation\logs`.

### How each section is enforced
| Section | Mechanism |
|---|---|
| 1 Account Policies | `secedit /configure` (`[System Access]`) |
| 2.2 User Rights | `secedit /configure` (`[Privilege Rights]`), role-aware SIDs |
| 2.3 Security Options | registry (`Set-CISRegValue`) |
| 9 Windows Firewall | registry |
| 17 Advanced Audit Policy | `auditpol /set` |
| 18 Admin Templates (Computer) | registry |
| 19 Admin Templates (User) | per-user registry — see note below |

---

## 3. Coverage

See `COVERAGE.md` for the exact, generated numbers. In summary, of **429**
recommendations parsed from the benchmark:

- **392 are automated** (registry, per-user registry, `security_policy` for
  password/lockout/user-rights, and `audit_policy`).
- **15 registry controls are flagged `REVIEW`** — the benchmark prescribes an
  *organization-specific* value (e.g. a legal notice text, a log-size threshold,
  or an enumerated choice). These are **checked for existence** in the scan and are
  **intentionally not auto-set** by the remediation; a `Write-CISWarn` lists them so
  you can set the value your organization has chosen.
- **37 are manual / service** controls that have no single registry or policy
  backing (procedural checks, or System Services items). The scan emits an
  InSpec `skip` carrying the recommendation title and remediation guidance so
  they appear in reports rather than silently passing.

### Note on Section 19 (per-user / `HKEY_USERS`)
User-scope settings live under each user's hive (`HKEY_USERS\<SID>`), not a single
machine key. The behaviour is therefore necessarily different from machine settings:

- **Scan:** enumerates the interactive-user hives currently loaded
  (`S-1-5-21-*`) and checks each. If none are loaded, the control `skip`s with an
  explanation rather than passing — a scan cannot load a logged-off user's hive.
- **Remediation:** writes every currently-loaded interactive-user hive **and**
  `.DEFAULT` (so newly-created profiles inherit it). Users who are not logged on
  are not modified by the script. For complete and durable coverage, enforce these
  via Group Policy (the matching GPO path is in each control's source comment).

---

## 4. Caveats & notes

- This profile is **generated from the benchmark text**. Treat the `REVIEW` and
  manual items as a worklist, and confirm the registry paths / prescribed values
  against your licensed copy of the CIS PDF before relying on them in production.
- secedit (user rights, account policy), audit policy, and per-user settings
  generally take effect at the next policy refresh / logon. A **reboot** after
  remediation is recommended before re-scanning.
- The remediation makes real changes to security policy. Always run `-WhatIf`
  first, keep the auto-backup, and validate on a non-production host.
- After remediation, **re-run the scan** to confirm the resulting state and to see
  which `REVIEW`/manual items still need attention.

## 5. Extending to 100%

To close the remaining gap:
1. Work through the `REVIEW` registry controls in `COVERAGE.md`, replacing the
   existence check with the concrete value your organization standardises on
   (and add the matching `Set-CISRegValue` line to the relevant remediation section).
2. Implement the **manual / service** controls (section 5 services can be driven
   with the `service` / `windows_service` InSpec resource and `Set-Service`
   remediation; procedural items may stay documented `skip`s).
3. For the handful of recommendations that prescribe **multiple registry values**,
   add the additional value checks/sets (the generator currently keeps the primary
   value as the representative check).
