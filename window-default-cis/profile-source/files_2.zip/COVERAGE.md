# Coverage

Total recommendations: **429**

| Mechanism | Count | InSpec resource |
|---|---|---|
| Registry (machine) | 289 | `registry_key` |
| Registry (per-user) | 11 | `registry_key` over `HKEY_USERS\<SID>` |
| Password policy | 6 | `security_policy` |
| Account lockout | 4 | `security_policy` |
| User rights | 48 | `security_policy` |
| Advanced audit policy | 34 | `audit_policy` |
| Manual / service | 37 | `skip` (documented) |

Automated coverage: **392** of 429 recommendations.

Registry controls flagged REVIEW (organization-specific value): 15 -> 2.3.7.4, 2.3.7.5, 2.3.10.7, 2.3.10.8, 2.3.10.9, 2.3.10.11, 9.1.4, 9.2.4, 9.3.6, 18.6.14.1, 18.9.20.1.13, 18.9.23.1, 18.10.58.2, 18.10.77.2.1, 18.10.94.4.2
