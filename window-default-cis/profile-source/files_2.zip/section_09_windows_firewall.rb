# encoding: UTF-8
# CIS Microsoft Windows Server 2022 Benchmark v5.0.0
# Section 9 - Windows Defender Firewall with Advanced Security
# Auto-generated; verify organization-specific (REVIEW) controls.

control 'cis-9.1.1' do
  title 'Ensure \'Windows Firewall: Domain: Firewall state\' is set to \'On (recommended)\' (Automated)'
  impact 0.5
  tag cis_id: '9.1.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile') do
    its('EnableFirewall') { should cmp == 1 }
  end
end

control 'cis-9.1.2' do
  title 'Ensure \'Windows Firewall: Domain: Inbound connections\' is set to \'Block (default)\' (Automated)'
  impact 0.5
  tag cis_id: '9.1.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile') do
    its('DefaultInboundAction') { should cmp == 1 }
  end
end

control 'cis-9.1.3' do
  title 'Ensure \'Windows Firewall: Domain: Settings: Display a notification\' is set to \'No\' (Automated)'
  impact 0.5
  tag cis_id: '9.1.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile') do
    its('DisableNotifications') { should cmp == 1 }
  end
end

control 'cis-9.1.4' do
  title 'Ensure \'Windows Firewall: Domain: Logging: Name\' is configured (Automated)'
  impact 0.5
  tag cis_id: '9.1.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile\\Logging') do
    # REVIEW: organization-specific value -- benchmark prescribes: <path>\<filename>.log. Where <path> is the location and <file> is
    it { should have_property 'LogFilePath' }
  end
end

control 'cis-9.1.5' do
  title 'Ensure \'Windows Firewall: Domain: Logging: Size limit (KB)\' is set to \'16,384 KB or greater\' (Automated)'
  impact 0.5
  tag cis_id: '9.1.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile\\Logging') do
    its('LogFileSize') { should cmp == 16384 }
  end
end

control 'cis-9.1.6' do
  title 'Ensure \'Windows Firewall: Domain: Logging: Log dropped packets\' is set to \'Yes\' (Automated)'
  impact 0.5
  tag cis_id: '9.1.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile\\Logging') do
    its('LogDroppedPackets') { should cmp == 1 }
  end
end

control 'cis-9.1.7' do
  title 'Ensure \'Windows Firewall: Domain: Logging: Log successful connections\' is set to \'Yes\' (Automated)'
  impact 0.5
  tag cis_id: '9.1.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\DomainProfile\\Logging') do
    its('LogSuccessfulConnections') { should cmp == 1 }
  end
end

control 'cis-9.2.1' do
  title 'Ensure \'Windows Firewall: Private: Firewall state\' is set to \'On (recommended)\' (Automated)'
  impact 0.5
  tag cis_id: '9.2.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile') do
    its('EnableFirewall') { should cmp == 1 }
  end
end

control 'cis-9.2.2' do
  title 'Ensure \'Windows Firewall: Private: Inbound connections\' is set to \'Block (default)\' (Automated)'
  impact 0.5
  tag cis_id: '9.2.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile') do
    its('DefaultInboundAction') { should cmp == 1 }
  end
end

control 'cis-9.2.3' do
  title 'Ensure \'Windows Firewall: Private: Settings: Display a notification\' is set to \'No\' (Automated)'
  impact 0.5
  tag cis_id: '9.2.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile') do
    its('DisableNotifications') { should cmp == 1 }
  end
end

control 'cis-9.2.4' do
  title 'Ensure \'Windows Firewall: Private: Logging: Name\' is configured (Automated)'
  impact 0.5
  tag cis_id: '9.2.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile\\Logging') do
    # REVIEW: organization-specific value -- benchmark prescribes: <path>\<filename>.log. Where <path> is the location and <file> is
    it { should have_property 'LogFilePath' }
  end
end

control 'cis-9.2.5' do
  title 'Ensure \'Windows Firewall: Private: Logging: Size limit (KB)\' is set to \'16,384 KB or greater\' (Automated)'
  impact 0.5
  tag cis_id: '9.2.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile\\Logging') do
    its('LogFileSize') { should cmp == 16384 }
  end
end

control 'cis-9.2.6' do
  title 'Ensure \'Windows Firewall: Private: Logging: Log dropped packets\' is set to \'Yes\' (Automated)'
  impact 0.5
  tag cis_id: '9.2.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile\\Logging') do
    its('LogDroppedPackets') { should cmp == 1 }
  end
end

control 'cis-9.2.7' do
  title 'Ensure \'Windows Firewall: Private: Logging: Log successful connections\' is set to \'Yes\' (Automated)'
  impact 0.5
  tag cis_id: '9.2.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PrivateProfile\\Logging') do
    its('LogSuccessfulConnections') { should cmp == 1 }
  end
end

control 'cis-9.3.1' do
  title 'Ensure \'Windows Firewall: Public: Firewall state\' is set to \'On (recommended)\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.1'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile') do
    its('EnableFirewall') { should cmp == 1 }
  end
end

control 'cis-9.3.2' do
  title 'Ensure \'Windows Firewall: Public: Inbound connections\' is set to \'Block (default)\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.2'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile') do
    its('DefaultInboundAction') { should cmp == 1 }
  end
end

control 'cis-9.3.3' do
  title 'Ensure \'Windows Firewall: Public: Settings: Display a notification\' is set to \'No\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.3'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile') do
    its('DisableNotifications') { should cmp == 1 }
  end
end

control 'cis-9.3.4' do
  title 'Ensure \'Windows Firewall: Public: Settings: Apply local firewall rules\' is set to \'No\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.4'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile') do
    its('AllowLocalPolicyMerge') { should cmp == 0 }
  end
end

control 'cis-9.3.5' do
  title 'Ensure \'Windows Firewall: Public: Settings: Apply local connection security rules\' is set to \'No\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.5'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile') do
    its('AllowLocalIPsecPolicyMerge') { should cmp == 0 }
  end
end

control 'cis-9.3.6' do
  title 'Ensure \'Windows Firewall: Public: Logging: Name\' is configured (Automated)'
  impact 0.5
  tag cis_id: '9.3.6'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile\\Logging') do
    # REVIEW: organization-specific value -- benchmark prescribes: <path>\<filename>.log. Where <path> is the location and <file> is
    it { should have_property 'LogFilePath' }
  end
end

control 'cis-9.3.7' do
  title 'Ensure \'Windows Firewall: Public: Logging: Size limit (KB)\' is set to \'16,384 KB or greater\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.7'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile\\Logging') do
    its('LogFileSize') { should cmp == 16384 }
  end
end

control 'cis-9.3.8' do
  title 'Ensure \'Windows Firewall: Public: Logging: Log dropped packets\' is set to \'Yes\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.8'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile\\Logging') do
    its('LogDroppedPackets') { should cmp == 1 }
  end
end

control 'cis-9.3.9' do
  title 'Ensure \'Windows Firewall: Public: Logging: Log successful connections\' is set to \'Yes\' (Automated)'
  impact 0.5
  tag cis_id: '9.3.9'
  tag level: ['L1']
  tag scope: 'ALL'
  tag mechanism: 'registry'
  ref 'CIS Microsoft Windows Server 2022 Benchmark v5.0.0', url: 'https://www.cisecurity.org/benchmark/microsoft_windows_server'
  describe registry_key('HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\WindowsFirewall\\PublicProfile\\Logging') do
    its('LogSuccessfulConnections') { should cmp == 1 }
  end
end
